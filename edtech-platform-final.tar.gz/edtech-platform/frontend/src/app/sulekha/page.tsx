'use client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { sulekhaApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { LoadingSpinner } from '@/components/ui';
import { formatDate, formatRelative } from '@/lib/utils';
import toast from 'react-hot-toast';
import { RefreshCw, CheckCircle, XCircle, Clock, Loader2, Info } from 'lucide-react';

export default function SulekhaPage() {
  const qc = useQueryClient();

  const { data: history, isLoading } = useQuery({
    queryKey: ['sulekha-history'],
    queryFn: () => sulekhaApi.history().then((r) => r.data),
    refetchInterval: 15000,
  });

  const syncMutation = useMutation({
    mutationFn: () => sulekhaApi.syncNow().then((r) => r.data),
    onSuccess: (data) => {
      toast.success(`Sync complete! ${data.leadsAdded} leads added, ${data.leadsSkipped} skipped.`);
      qc.invalidateQueries({ queryKey: ['sulekha-history'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Sync failed. Check API config.'),
  });

  const lastSync = history?.[0];
  const totalAdded = history?.reduce((s: number, h: any) => s + (h.leadsAdded || 0), 0) || 0;
  const totalSyncs = history?.length || 0;
  const successRate = totalSyncs > 0
    ? Math.round((history.filter((h: any) => h.status === 'SUCCESS').length / totalSyncs) * 100)
    : 0;

  return (
    <AppLayout title="Sulekha Lead Sync">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Info Banner */}
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex gap-3">
          <Info className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-orange-800">
            <strong>Auto-sync schedule:</strong> Daily at 6:00 AM IST.
            Duplicate detection runs on: Sulekha ID → Phone → Email.
            Leads are auto-assigned to the agent with fewest active leads.
            Failed syncs retry up to 3 times before marking as FAILED.
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4">
          <div className="card p-5 text-center">
            <div className="text-3xl font-bold text-blue-600">{totalSyncs}</div>
            <div className="text-sm text-gray-500 mt-1">Total Syncs</div>
          </div>
          <div className="card p-5 text-center">
            <div className="text-3xl font-bold text-green-600">{totalAdded}</div>
            <div className="text-sm text-gray-500 mt-1">Total Leads Added</div>
          </div>
          <div className="card p-5 text-center">
            <div className="text-3xl font-bold text-indigo-600">{successRate}%</div>
            <div className="text-sm text-gray-500 mt-1">Success Rate</div>
          </div>
        </div>

        {/* Manual Sync Card */}
        <div className="card p-6">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold text-gray-800 text-lg">Manual Sync</h3>
              <p className="text-sm text-gray-500 mt-1">
                Trigger an immediate sync from Sulekha. This runs the same dedup logic as the daily cron.
              </p>
              {lastSync && (
                <p className="text-xs text-gray-400 mt-2">
                  Last sync: {formatRelative(lastSync.startedAt)} —
                  <span className={`ml-1 font-medium ${lastSync.status === 'SUCCESS' ? 'text-green-600' : 'text-red-600'}`}>
                    {lastSync.status}
                  </span>
                  {lastSync.status === 'SUCCESS' && ` (+${lastSync.leadsAdded} leads)`}
                </p>
              )}
            </div>
            <button
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              className="btn-primary flex items-center gap-2 text-sm ml-4 flex-shrink-0"
            >
              {syncMutation.isPending
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Syncing...</>
                : <><RefreshCw className="w-4 h-4" /> Sync Now</>
              }
            </button>
          </div>

          {/* Live sync result */}
          {syncMutation.data && (
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-xl">
              <div className="grid grid-cols-3 gap-4 text-sm text-center">
                <div>
                  <div className="text-2xl font-bold text-green-700">{syncMutation.data.leadsAdded}</div>
                  <div className="text-gray-500">Leads Added</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600">{syncMutation.data.leadsSkipped}</div>
                  <div className="text-gray-500">Skipped (Dupes)</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-600">
                    {syncMutation.data.leadsAdded + syncMutation.data.leadsSkipped}
                  </div>
                  <div className="text-gray-500">Total Fetched</div>
                </div>
              </div>
              {syncMutation.data.errors?.length > 0 && (
                <div className="mt-3 text-xs text-red-600 space-y-0.5">
                  <div className="font-medium">Errors:</div>
                  {syncMutation.data.errors.slice(0, 5).map((e: string, i: number) => (
                    <div key={i}>• {e}</div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Sync History Table */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-800">Sync History</h3>
          </div>
          {isLoading ? <LoadingSpinner /> : !history?.length ? (
            <div className="py-12 text-center text-gray-500 text-sm">No sync history yet. Run your first sync above.</div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  {['Started', 'Completed', 'Status', 'Leads Added', 'Skipped', 'Notes'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {history.map((sync: any) => (
                  <tr key={sync.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="text-gray-800">{formatDate(sync.startedAt)}</div>
                      <div className="text-xs text-gray-400">{formatRelative(sync.startedAt)}</div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">
                      {sync.completedAt ? formatDate(sync.completedAt) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        {sync.status === 'SUCCESS' && <CheckCircle className="w-4 h-4 text-green-500" />}
                        {sync.status === 'FAILED' && <XCircle className="w-4 h-4 text-red-500" />}
                        {sync.status === 'RUNNING' && <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />}
                        <span className={`font-medium text-xs ${
                          sync.status === 'SUCCESS' ? 'text-green-700' :
                          sync.status === 'FAILED' ? 'text-red-700' : 'text-blue-700'
                        }`}>{sync.status}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-green-700">+{sync.leadsAdded || 0}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">{sync.leadsSkipped || 0}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">
                      {sync.errorMessage ? (
                        <span className="text-red-600">{sync.errorMessage.slice(0, 80)}</span>
                      ) : sync.status === 'SUCCESS' ? (
                        <span className="text-green-600">Completed successfully</span>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Config reminder */}
        <div className="card p-5 bg-gray-50">
          <h4 className="font-medium text-gray-700 mb-2 text-sm">⚙️ Sulekha API Configuration</h4>
          <p className="text-xs text-gray-500 mb-2">
            Set these in your backend <code className="bg-gray-200 px-1 rounded">.env</code> file to enable live Sulekha integration.
            Without them, the system runs in demo mode with mock leads.
          </p>
          <div className="font-mono text-xs bg-gray-100 rounded-lg p-3 space-y-1">
            <div><span className="text-blue-600">SULEKHA_API_KEY</span>=your-api-key-from-sulekha-dashboard</div>
            <div><span className="text-blue-600">SULEKHA_API_URL</span>=https://api.sulekha.com/v1/leads</div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
