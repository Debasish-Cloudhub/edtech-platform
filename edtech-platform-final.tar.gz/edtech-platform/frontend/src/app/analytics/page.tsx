'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi, leadsApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { LoadingSpinner } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, PieChart, Pie, Cell,
} from 'recharts';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function AnalyticsPage() {
  const [year, setYear] = useState(new Date().getFullYear());

  const { data: revExp, isLoading: loadingRevExp } = useQuery({
    queryKey: ['rev-exp', year],
    queryFn: () => dashboardApi.revenueVsExpense(year).then((r) => r.data),
  });

  const { data: funnel } = useQuery({
    queryKey: ['funnel'],
    queryFn: () => dashboardApi.funnel().then((r) => r.data),
  });

  const { data: incentiveSummary } = useQuery({
    queryKey: ['incentive-summary'],
    queryFn: () => leadsApi.incentiveSummary().then((r) => r.data),
  });

  const { data: adminData } = useQuery({
    queryKey: ['dashboard-admin'],
    queryFn: () => dashboardApi.admin().then((r) => r.data),
  });

  const chartData = revExp?.map((d: any, i: number) => ({
    ...d,
    month: MONTHS[d.month - 1],
    profit: d.revenue - d.expenses,
  })) || [];

  const COLORS = ['#3b82f6', '#f59e0b', '#22c55e', '#ef4444'];

  const conversionRate = adminData?.overview?.conversionRate || '0%';
  const totalRevenue = adminData?.overview?.totalRevenue || 0;
  const totalIncentives = adminData?.overview?.totalIncentives || 0;

  return (
    <AppLayout title="Analytics">
      <div className="space-y-6">
        {/* Header Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-gray-700">Year:</label>
            <select className="input w-28" value={year} onChange={(e) => setYear(Number(e.target.value))}>
              {[2023, 2024, 2025, 2026].map((y) => <option key={y}>{y}</option>)}
            </select>
          </div>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Revenue', value: formatCurrency(totalRevenue), color: 'text-green-700' },
            { label: 'Total Incentives', value: formatCurrency(totalIncentives), color: 'text-purple-700' },
            { label: 'Conversion Rate', value: conversionRate, color: 'text-blue-700' },
            { label: 'Won Leads', value: incentiveSummary?.totalWon || 0, color: 'text-indigo-700' },
          ].map((kpi) => (
            <div key={kpi.label} className="card p-5 text-center">
              <div className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</div>
              <div className="text-sm text-gray-500 mt-1">{kpi.label}</div>
            </div>
          ))}
        </div>

        {/* Revenue vs Expense Line Chart */}
        <div className="card p-5">
          <h3 className="font-semibold text-gray-800 mb-5">Revenue vs Expenses vs Incentives ({year})</h3>
          {loadingRevExp ? <LoadingSpinner /> : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: any) => formatCurrency(v)} />
                <Legend />
                <Line type="monotone" dataKey="revenue" stroke="#22c55e" strokeWidth={2} dot={false} name="Revenue" />
                <Line type="monotone" dataKey="incentives" stroke="#8b5cf6" strokeWidth={2} dot={false} name="Incentives" />
                <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} dot={false} name="Expenses" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Two charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Lead Funnel Bar */}
          {funnel && (
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Lead Conversion Funnel</h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={funnel} layout="vertical" margin={{ left: 10, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="stage" tick={{ fontSize: 11 }}
                    tickFormatter={(v) => ({ INITIATED: 'Initiated', IN_PROGRESS: 'In Progress', WON: 'Won', LOST: 'Lost' }[v] || v)} />
                  <Tooltip />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {funnel.map((entry: any, idx: number) => (
                      <Cell key={idx} fill={['#3b82f6','#f59e0b','#22c55e','#ef4444'][idx] || '#94a3b8'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Incentive by source pie */}
          {incentiveSummary && (
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Incentive Source Breakdown</h3>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={Object.entries(incentiveSummary.bySource || {}).map(([name, value]) => ({ name, value }))}
                    cx="50%" cy="50%" outerRadius={75}
                    dataKey="value" nameKey="name"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {Object.keys(incentiveSummary.bySource || {}).map((_: any, idx: number) => (
                      <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>

              {/* By agent table */}
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="text-xs font-semibold text-gray-500 uppercase mb-2">Incentives by Agent</div>
                {(incentiveSummary.byUser || []).slice(0, 5).map((agent: any, i: number) => (
                  <div key={i} className="flex items-center justify-between py-1.5 text-sm">
                    <span className="text-gray-700">{agent.name}</span>
                    <div className="text-right">
                      <div className="font-semibold text-green-700">{formatCurrency(agent.totalIncentive)}</div>
                      <div className="text-xs text-gray-400">{agent.count} won</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Monthly Profit Table */}
        {chartData.length > 0 && (
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b">
              <h3 className="font-semibold text-gray-800">Monthly Breakdown ({year})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    {['Month', 'Revenue', 'Incentives', 'Expenses', 'Net Profit'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {chartData.map((row: any) => (
                    <tr key={row.month} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-700">{row.month}</td>
                      <td className="px-4 py-3 text-green-700 font-medium">{formatCurrency(row.revenue)}</td>
                      <td className="px-4 py-3 text-purple-700">{formatCurrency(row.incentives)}</td>
                      <td className="px-4 py-3 text-red-600">{formatCurrency(row.expenses)}</td>
                      <td className={`px-4 py-3 font-semibold ${row.profit >= 0 ? 'text-green-700' : 'text-red-600'}`}>
                        {formatCurrency(row.profit)}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-gray-50 border-t-2 border-gray-300 font-semibold">
                    <td className="px-4 py-3 text-gray-800">Total</td>
                    <td className="px-4 py-3 text-green-800">{formatCurrency(chartData.reduce((s: number, r: any) => s + r.revenue, 0))}</td>
                    <td className="px-4 py-3 text-purple-800">{formatCurrency(chartData.reduce((s: number, r: any) => s + r.incentives, 0))}</td>
                    <td className="px-4 py-3 text-red-700">{formatCurrency(chartData.reduce((s: number, r: any) => s + r.expenses, 0))}</td>
                    <td className="px-4 py-3 text-gray-900">{formatCurrency(chartData.reduce((s: number, r: any) => s + r.profit, 0))}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
