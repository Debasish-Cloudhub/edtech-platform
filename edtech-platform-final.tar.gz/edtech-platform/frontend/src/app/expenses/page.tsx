'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { expensesApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { EmptyState, LoadingSpinner, Modal, Pagination } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { formatCurrency, formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';
import { Plus, Check, X, Loader2, Receipt } from 'lucide-react';

const CATEGORIES = ['Travel', 'Accommodation', 'Food', 'Marketing', 'Software', 'Office', 'Communication', 'Other'];
const STATUS_COLORS: Record<string, string> = {
  PENDING: 'badge bg-yellow-100 text-yellow-800',
  APPROVED: 'badge bg-green-100 text-green-800',
  REJECTED: 'badge bg-red-100 text-red-800',
};

export default function ExpensesPage() {
  const { isAdmin, isFinance, user } = useAuth();
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [monthFilter, setMonthFilter] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['expenses', statusFilter, monthFilter],
    queryFn: () => expensesApi.list({
      status: statusFilter || undefined,
      month: monthFilter ? Number(monthFilter) : undefined,
      year: new Date().getFullYear(),
    }).then((r) => r.data),
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => expensesApi.approve(id),
    onSuccess: () => { toast.success('Expense approved'); qc.invalidateQueries({ queryKey: ['expenses'] }); },
  });

  const rejectMutation = useMutation({
    mutationFn: (id: string) => expensesApi.reject(id),
    onSuccess: () => { toast.success('Expense rejected'); qc.invalidateQueries({ queryKey: ['expenses'] }); },
  });

  const expenses = data?.data || [];
  const totalAmount = data?.totalAmount || 0;

  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  return (
    <AppLayout title="Expenses">
      <div className="space-y-5">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <select className="input w-36" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">All Status</option>
            <option value="PENDING">Pending</option>
            <option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option>
          </select>
          <select className="input w-32" value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)}>
            <option value="">All Months</option>
            {months.map((m, i) => <option key={i+1} value={i+1}>{m}</option>)}
          </select>
          <div className="ml-auto flex items-center gap-3">
            <div className="text-sm text-gray-600">
              Total: <span className="font-semibold text-gray-900">{formatCurrency(totalAmount)}</span>
            </div>
            <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2 text-sm">
              <Plus className="w-4 h-4" /> Log Expense
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="card overflow-hidden">
          {isLoading ? <LoadingSpinner /> : expenses.length === 0 ? (
            <EmptyState title="No expenses found" description="Log your first expense to get started"
              action={<button onClick={() => setShowCreate(true)} className="btn-primary text-sm">Log Expense</button>} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    {['Description', 'Category', 'Amount', 'Month', 'Logged By', 'Status', 'Actions'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {expenses.map((exp: any) => (
                    <tr key={exp.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800">{exp.description}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full">{exp.category}</span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-gray-900">{formatCurrency(exp.amount, exp.currency)}</td>
                      <td className="px-4 py-3 text-gray-500">{months[exp.month - 1]} {exp.year}</td>
                      <td className="px-4 py-3 text-gray-600">{exp.user?.name || '—'}</td>
                      <td className="px-4 py-3">
                        <span className={STATUS_COLORS[exp.status] || 'badge bg-gray-100 text-gray-700'}>{exp.status}</span>
                      </td>
                      <td className="px-4 py-3">
                        {exp.status === 'PENDING' && (isAdmin || isFinance) && (
                          <div className="flex items-center gap-2">
                            <button onClick={() => approveMutation.mutate(exp.id)}
                              className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg" title="Approve">
                              <Check className="w-4 h-4" />
                            </button>
                            <button onClick={() => rejectMutation.mutate(exp.id)}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg" title="Reject">
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                        {exp.approvedAt && (
                          <div className="text-xs text-gray-400">{formatDate(exp.approvedAt)}</div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showCreate && (
        <CreateExpenseModal
          onClose={() => setShowCreate(false)}
          onSuccess={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['expenses'] }); }}
        />
      )}
    </AppLayout>
  );
}

function CreateExpenseModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState({
    category: 'Travel', amount: '', description: '',
    month: String(new Date().getMonth() + 1), year: String(new Date().getFullYear()),
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => expensesApi.create(data),
    onSuccess: () => { toast.success('Expense logged!'); onSuccess(); },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed to log expense'),
  });

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.amount || !form.description) return toast.error('All fields required');
    createMutation.mutate({
      category: form.category, amount: Number(form.amount),
      description: form.description, month: Number(form.month), year: Number(form.year),
    });
  };

  return (
    <Modal open onClose={onClose} title="Log Expense">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label">Category</label>
          <select className="input" value={form.category} onChange={(e) => set('category', e.target.value)}>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Amount (INR) *</label>
          <input className="input" type="number" placeholder="1500" value={form.amount}
            onChange={(e) => set('amount', e.target.value)} required min="1" />
        </div>
        <div>
          <label className="label">Description *</label>
          <input className="input" placeholder="Flight to Delhi for client meeting" value={form.description}
            onChange={(e) => set('description', e.target.value)} required />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Month</label>
            <select className="input" value={form.month} onChange={(e) => set('month', e.target.value)}>
              {months.map((m, i) => <option key={i+1} value={i+1}>{m}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Year</label>
            <input className="input" type="number" value={form.year} onChange={(e) => set('year', e.target.value)} />
          </div>
        </div>
        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          <button type="submit" disabled={createMutation.isPending} className="btn-primary flex items-center gap-2">
            {createMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Log Expense
          </button>
        </div>
      </form>
    </Modal>
  );
}
