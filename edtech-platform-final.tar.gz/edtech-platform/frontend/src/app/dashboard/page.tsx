'use client';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { StatCard, StageBadge, LoadingSpinner } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { formatCurrency, formatDate } from '@/lib/utils';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts';
import {
  Users, TrendingUp, DollarSign, AlertTriangle, FileText, CheckCircle, Clock, Receipt,
} from 'lucide-react';

const STAGE_COLORS = { INITIATED: '#3b82f6', IN_PROGRESS: '#f59e0b', WON: '#22c55e', LOST: '#ef4444' };

export default function DashboardPage() {
  const { user, isAdmin, isSales } = useAuth();

  const { data: adminData, isLoading: loadingAdmin } = useQuery({
    queryKey: ['dashboard-admin'],
    queryFn: () => dashboardApi.admin().then((r) => r.data),
    enabled: isAdmin,
  });

  const { data: salesData, isLoading: loadingSales } = useQuery({
    queryKey: ['dashboard-sales'],
    queryFn: () => dashboardApi.sales().then((r) => r.data),
    enabled: isSales,
  });

  const { data: funnelData } = useQuery({
    queryKey: ['funnel'],
    queryFn: () => dashboardApi.funnel().then((r) => r.data),
  });

  const isLoading = isAdmin ? loadingAdmin : loadingSales;
  const d = isAdmin ? adminData : salesData;

  if (isLoading) return (
    <AppLayout title="Dashboard">
      <LoadingSpinner text="Loading dashboard..." />
    </AppLayout>
  );

  const overview = d?.overview || {};

  return (
    <AppLayout title="Dashboard">
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Leads" value={overview.totalLeads ?? 0} icon={FileText}
            subtitle={`${overview.leadsThisMonth ?? 0} this month`} color="blue"
            trend={overview.leadGrowth ? { value: `${overview.leadGrowth}% vs last month`, positive: Number(overview.leadGrowth) >= 0 } : undefined} />
          <StatCard title="Won Leads" value={overview.wonTotal ?? overview.wonLeads ?? 0} icon={CheckCircle}
            subtitle={`${overview.conversionRate} conversion`} color="green" />
          <StatCard title="Total Incentives" value={formatCurrency(overview.totalIncentive)} icon={DollarSign}
            subtitle="From closed deals" color="purple" />
          <StatCard title="SLA Breaches" value={overview.slaBreaches ?? 0} icon={AlertTriangle}
            subtitle="Active leads overdue" color="red" />
        </div>

        {isAdmin && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard title="Total Revenue" value={formatCurrency(overview.totalRevenue)} icon={TrendingUp} color="green" />
            <StatCard title="Active Users" value={overview.totalUsers ?? 0} icon={Users} color="blue" />
            <StatCard title="Pending Expenses" value={overview.pendingExpenses ?? 0} icon={Receipt} color="yellow" />
            <StatCard title="Expenses (Month)" value={formatCurrency(overview.approvedExpensesThisMonth)} icon={Receipt} color="red" />
          </div>
        )}

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Funnel Chart */}
          {funnelData && (
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Lead Pipeline</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={funnelData} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="stage" tick={{ fontSize: 11 }}
                    tickFormatter={(v) => ({ INITIATED: 'Initiated', IN_PROGRESS: 'In Progress', WON: 'Won', LOST: 'Lost' }[v] || v)} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {funnelData.map((entry: any, idx: number) => (
                      <Cell key={idx} fill={STAGE_COLORS[entry.stage as keyof typeof STAGE_COLORS] || '#94a3b8'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Stage Distribution Pie */}
          {d?.leadsByStage && (
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Stage Distribution</h3>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={Object.entries(d.leadsByStage).map(([stage, count]) => ({ stage, count }))}
                    dataKey="count" nameKey="stage" cx="50%" cy="50%" outerRadius={80} label={({ stage, percent }) =>
                      `${({ INITIATED: 'Init', IN_PROGRESS: 'Prog', WON: 'Won', LOST: 'Lost' }[stage] || stage)} ${(percent * 100).toFixed(0)}%`}>
                    {Object.entries(d.leadsByStage).map(([stage], idx) => (
                      <Cell key={idx} fill={STAGE_COLORS[stage as keyof typeof STAGE_COLORS] || '#94a3b8'} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: any, name: string) => [v, name]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Recent Leads + Top Agents */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Leads */}
          {d?.recentLeads && (
            <div className="card">
              <div className="px-5 py-4 border-b border-gray-100">
                <h3 className="font-semibold text-gray-800">Recent Leads</h3>
              </div>
              <div className="divide-y divide-gray-50">
                {d.recentLeads.map((lead: any) => (
                  <div key={lead.id} className="px-5 py-3 flex items-center justify-between hover:bg-gray-50">
                    <div>
                      <div className="text-sm font-medium text-gray-800">{lead.name}</div>
                      <div className="text-xs text-gray-500">{lead.phone} · {lead.courseInterested}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <StageBadge stage={lead.stage} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top Sales Agents (admin only) */}
          {isAdmin && d?.topSalesAgents && (
            <div className="card">
              <div className="px-5 py-4 border-b border-gray-100">
                <h3 className="font-semibold text-gray-800">Top Sales Agents</h3>
              </div>
              <div className="divide-y divide-gray-50">
                {d.topSalesAgents.length === 0 ? (
                  <div className="px-5 py-8 text-center text-sm text-gray-500">No data yet</div>
                ) : (
                  d.topSalesAgents.map((agent: any, idx: number) => (
                    <div key={agent.user.id} className="px-5 py-3 flex items-center gap-3">
                      <div className="w-7 h-7 bg-primary-100 rounded-full flex items-center justify-center text-xs font-bold text-primary-700">
                        {idx + 1}
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-800">{agent.user.name}</div>
                        <div className="text-xs text-gray-500">{agent.wonCount} won · {formatCurrency(agent.totalIncentive)} incentive</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Breached Leads (sales) */}
          {isSales && d?.breachedLeads && (
            <div className="card">
              <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500" />
                <h3 className="font-semibold text-gray-800">SLA Breaches</h3>
              </div>
              <div className="divide-y divide-gray-50">
                {d.breachedLeads.length === 0 ? (
                  <div className="px-5 py-8 text-center text-sm text-green-600">✓ No SLA breaches!</div>
                ) : (
                  d.breachedLeads.map((lead: any) => (
                    <div key={lead.id} className="px-5 py-3">
                      <div className="text-sm font-medium text-gray-800">{lead.name}</div>
                      <div className="text-xs text-red-600 mt-0.5">
                        {lead.stage} · In stage since {formatDate(lead.stageStartDate)}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
