'use client';
import { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { excelApi, sulekhaApi, dashboardApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { LoadingSpinner } from '@/components/ui';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';
import {
  Upload, Download, RefreshCw, Settings2, Save, Loader2,
  CheckCircle, XCircle, AlertTriangle, FileSpreadsheet,
} from 'lucide-react';

export default function SettingsPage() {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadResult, setUploadResult] = useState<any>(null);

  // System config
  const { data: config, isLoading: loadingConfig } = useQuery({
    queryKey: ['system-config'],
    queryFn: () => dashboardApi.config().then((r) => r.data),
  });

  const [configValues, setConfigValues] = useState<Record<string, string>>({});

  // Merge config into editable state
  const getConfigVal = (key: string) =>
    configValues[key] !== undefined ? configValues[key] : config?.[key] || '';

  const updateConfigMutation = useMutation({
    mutationFn: ({ key, value }: { key: string; value: string }) =>
      dashboardApi.updateConfig(key, value),
    onSuccess: () => { toast.success('Config updated'); qc.invalidateQueries({ queryKey: ['system-config'] }); },
    onError: () => toast.error('Failed to update config'),
  });

  // Excel upload
  const uploadMutation = useMutation({
    mutationFn: (file: File) => excelApi.upload(file).then((r) => r.data),
    onSuccess: (data) => {
      setUploadResult(data);
      toast.success(`Import done: ${data.imported} rows imported`);
      qc.invalidateQueries({ queryKey: ['colleges'] });
      qc.invalidateQueries({ queryKey: ['courses'] });
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Upload failed'),
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.endsWith('.xlsx')) return toast.error('Only .xlsx files are supported');
    setUploadResult(null);
    uploadMutation.mutate(file);
    e.target.value = '';
  };

  const downloadTemplate = async () => {
    try {
      const res = await excelApi.template();
      const url = URL.createObjectURL(new Blob([res.data]));
      const a = document.createElement('a');
      a.href = url; a.download = 'edtech-template.xlsx'; a.click();
      URL.revokeObjectURL(url);
    } catch { toast.error('Failed to download template'); }
  };

  // Sulekha sync
  const syncMutation = useMutation({
    mutationFn: () => sulekhaApi.syncNow().then((r) => r.data),
    onSuccess: (data) => {
      toast.success(`Sync complete: ${data.leadsAdded} leads added`);
      qc.invalidateQueries({ queryKey: ['sulekha-history'] });
    },
    onError: () => toast.error('Sync failed'),
  });

  const { data: syncHistory } = useQuery({
    queryKey: ['sulekha-history'],
    queryFn: () => sulekhaApi.history().then((r) => r.data),
  });

  // Recalculate incentives
  const recalcMutation = useMutation({
    mutationFn: () => import('@/lib/api').then(({ leadsApi: l }) => l.recalculateIncentives().then((r) => r.data)),
    onSuccess: (data) => toast.success(`Recalculated incentives for ${data.updated} leads`),
  });

  const CONFIG_KEYS = [
    { key: 'DEFAULT_INCENTIVE_PERCENT', label: 'Default Incentive %', desc: 'Used when course has no incentive defined in Excel', suffix: '%' },
    { key: 'SLA_INITIATED_DAYS', label: 'SLA — Initiated Stage (days)', desc: 'Max days a lead can stay in Initiated stage', suffix: 'd' },
    { key: 'SLA_IN_PROGRESS_DAYS', label: 'SLA — In Progress Stage (days)', desc: 'Max days a lead can stay in In Progress stage', suffix: 'd' },
  ];

  return (
    <AppLayout title="Settings">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* ── Excel Upload ─────────────────────────────── */}
        <div className="card p-6">
          <h3 className="font-semibold text-gray-800 mb-1 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-green-600" /> Excel Data Import
          </h3>
          <p className="text-sm text-gray-500 mb-5">
            Upload college and course data. System will auto-parse, update the database, and recalculate all incentives.
          </p>

          <div className="flex flex-wrap gap-3">
            <button onClick={downloadTemplate} className="btn-secondary flex items-center gap-2 text-sm">
              <Download className="w-4 h-4" /> Download Template
            </button>
            <button onClick={() => fileRef.current?.click()}
              disabled={uploadMutation.isPending}
              className="btn-primary flex items-center gap-2 text-sm">
              {uploadMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {uploadMutation.isPending ? 'Uploading...' : 'Upload Excel (.xlsx)'}
            </button>
            <input ref={fileRef} type="file" accept=".xlsx" onChange={handleFileChange} className="hidden" />
          </div>

          {/* Upload result */}
          {uploadResult && (
            <div className={`mt-4 p-4 rounded-xl border ${uploadResult.imported > 0 ? 'bg-green-50 border-green-200' : 'bg-yellow-50 border-yellow-200'}`}>
              <div className="flex items-center gap-2 font-semibold text-sm mb-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                Import Complete
              </div>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-700">{uploadResult.imported}</div>
                  <div className="text-gray-500">Rows Imported</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-700">{uploadResult.colleges}</div>
                  <div className="text-gray-500">Colleges</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-700">{uploadResult.courses}</div>
                  <div className="text-gray-500">Courses</div>
                </div>
              </div>
              {uploadResult.skipped > 0 && (
                <div className="mt-3 text-xs text-yellow-700 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" /> {uploadResult.skipped} rows skipped
                </div>
              )}
              {uploadResult.errors?.length > 0 && (
                <div className="mt-2 text-xs text-red-600 space-y-0.5">
                  {uploadResult.errors.slice(0, 5).map((e: string, i: number) => <div key={i}>• {e}</div>)}
                </div>
              )}
            </div>
          )}

          <div className="mt-4 pt-4 border-t border-gray-100">
            <button onClick={() => recalcMutation.mutate()} disabled={recalcMutation.isPending}
              className="btn-secondary text-sm flex items-center gap-2">
              {recalcMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              Recalculate All Incentives
            </button>
            <p className="text-xs text-gray-400 mt-1">
              Recalculates incentives for all active leads based on current Excel data
            </p>
          </div>
        </div>

        {/* ── System Config ────────────────────────────── */}
        <div className="card p-6">
          <h3 className="font-semibold text-gray-800 mb-1 flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-blue-600" /> System Configuration
          </h3>
          <p className="text-sm text-gray-500 mb-5">Configure SLA limits and default incentive percentage.</p>

          {loadingConfig ? <LoadingSpinner /> : (
            <div className="space-y-4">
              {CONFIG_KEYS.map(({ key, label, desc, suffix }) => (
                <div key={key} className="flex items-start gap-4">
                  <div className="flex-1">
                    <label className="label">{label}</label>
                    <p className="text-xs text-gray-400 mb-1">{desc}</p>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" className="input w-28"
                        value={getConfigVal(key)}
                        onChange={(e) => setConfigValues((v) => ({ ...v, [key]: e.target.value }))}
                      />
                      <span className="text-sm text-gray-500">{suffix}</span>
                      <button
                        onClick={() => updateConfigMutation.mutate({ key, value: getConfigVal(key) })}
                        disabled={updateConfigMutation.isPending}
                        className="btn-primary text-sm px-3 py-1.5 flex items-center gap-1">
                        <Save className="w-3.5 h-3.5" /> Save
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Sulekha Sync ─────────────────────────────── */}
        <div className="card p-6">
          <h3 className="font-semibold text-gray-800 mb-1 flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-orange-500" /> Sulekha Lead Sync
          </h3>
          <p className="text-sm text-gray-500 mb-4">
            Auto-syncs daily at 6:00 AM. Duplicate detection via phone/email. Manual sync available below.
          </p>

          <button onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending}
            className="btn-primary flex items-center gap-2 text-sm mb-5">
            {syncMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            {syncMutation.isPending ? 'Syncing...' : 'Sync Now'}
          </button>

          {/* Sync history */}
          <div>
            <div className="text-xs font-semibold text-gray-500 uppercase mb-2">Sync History</div>
            {!syncHistory?.length ? (
              <div className="text-sm text-gray-400">No sync history yet</div>
            ) : (
              <div className="space-y-2">
                {syncHistory.slice(0, 8).map((sync: any) => (
                  <div key={sync.id} className="flex items-center gap-3 text-sm py-2 border-b border-gray-50">
                    {sync.status === 'SUCCESS' ? (
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : sync.status === 'FAILED' ? (
                      <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                    ) : (
                      <Loader2 className="w-4 h-4 text-blue-500 animate-spin flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <span className="text-gray-700">{formatDate(sync.startedAt)}</span>
                      {sync.status === 'SUCCESS' && (
                        <span className="ml-2 text-gray-500">
                          +{sync.leadsAdded} added, {sync.leadsSkipped} skipped
                        </span>
                      )}
                      {sync.errorMessage && (
                        <span className="ml-2 text-red-500 text-xs">{sync.errorMessage.slice(0, 60)}</span>
                      )}
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      sync.status === 'SUCCESS' ? 'bg-green-100 text-green-700' :
                      sync.status === 'FAILED' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                    }`}>{sync.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
