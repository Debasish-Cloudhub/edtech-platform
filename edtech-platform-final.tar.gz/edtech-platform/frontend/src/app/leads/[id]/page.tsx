'use client';
import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { leadsApi, collegesApi, coursesApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { StageBadge, SourceBadge, SlaBadge, LoadingSpinner } from '@/components/ui';
import { formatCurrency, formatDate, formatRelative } from '@/lib/utils';
import toast from 'react-hot-toast';
import { ArrowLeft, Save, MessageSquare, Calculator, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

const STAGES = ['INITIATED', 'IN_PROGRESS', 'WON', 'LOST'];

export default function LeadDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const qc = useQueryClient();
  const [note, setNote] = useState('');
  const [editStage, setEditStage] = useState('');
  const [editCollege, setEditCollege] = useState('');
  const [editCourse, setEditCourse] = useState('');

  const { data: lead, isLoading } = useQuery({
    queryKey: ['lead', id],
    queryFn: () => leadsApi.get(id).then((r) => r.data),
    onSuccess: (d: any) => { setEditStage(d.stage); setEditCollege(d.college?.id || ''); setEditCourse(d.course?.id || ''); },
  } as any);

  const { data: sla } = useQuery({
    queryKey: ['lead-sla', id],
    queryFn: () => leadsApi.slaStatus(id).then((r) => r.data),
  });

  const { data: colleges } = useQuery({ queryKey: ['colleges'], queryFn: () => collegesApi.list().then((r) => r.data) });
  const { data: courses } = useQuery({
    queryKey: ['courses', editCollege],
    queryFn: () => coursesApi.list({ collegeId: editCollege }).then((r) => r.data),
    enabled: !!editCollege,
  });

  const { data: incentivePreview } = useQuery({
    queryKey: ['incentive-preview', editCourse],
    queryFn: () => leadsApi.incentivePreview(editCourse).then((r) => r.data),
    enabled: !!editCourse,
  });

  const updateMutation = useMutation({
    mutationFn: (data: any) => leadsApi.update(id, data),
    onSuccess: () => { toast.success('Lead updated!'); qc.invalidateQueries({ queryKey: ['lead', id] }); },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Update failed'),
  });

  const noteMutation = useMutation({
    mutationFn: () => leadsApi.addNote(id, note),
    onSuccess: () => { toast.success('Note added!'); setNote(''); qc.invalidateQueries({ queryKey: ['lead', id] }); },
  });

  if (isLoading) return <AppLayout title="Lead Detail"><LoadingSpinner /></AppLayout>;
  if (!lead) return <AppLayout title="Lead Detail"><div className="text-center py-20 text-gray-500">Lead not found</div></AppLayout>;

  const handleUpdate = () => {
    updateMutation.mutate({
      stage: editStage,
      collegeId: editCollege || undefined,
      courseId: editCourse || undefined,
    });
  };

  const activityIcon: Record<string, string> = {
    CREATED: '🟢', STAGE_CHANGE: '🔄', NOTE: '📝', ASSIGNED: '👤',
    INCENTIVE_CALCULATED: '💰', INCENTIVE_FINALIZED: '✅', SLA_BREACH: '⚠️',
  };

  return (
    <AppLayout title="Lead Detail">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Back + Header */}
        <div className="flex items-center gap-4">
          <Link href="/leads" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h2 className="text-xl font-bold text-gray-900">{lead.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <StageBadge stage={lead.stage} />
              <SourceBadge source={lead.source} />
              {lead.slaBreach && <SlaBadge isBreached />}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Lead Info */}
          <div className="lg:col-span-2 space-y-4">
            {/* Contact Info */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Contact Information</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-gray-500">Phone:</span> <span className="font-medium ml-2">{lead.phone}</span></div>
                <div><span className="text-gray-500">Email:</span> <span className="font-medium ml-2">{lead.email || '—'}</span></div>
                <div><span className="text-gray-500">Interest:</span> <span className="font-medium ml-2">{lead.courseInterested}</span></div>
                <div><span className="text-gray-500">Country:</span> <span className="font-medium ml-2">{lead.country?.name || lead.preferredCountry || '—'}</span></div>
                <div><span className="text-gray-500">Assigned:</span> <span className="font-medium ml-2">{lead.assignedUser?.name || 'Unassigned'}</span></div>
                <div><span className="text-gray-500">Created:</span> <span className="font-medium ml-2">{formatDate(lead.createdAt)}</span></div>
              </div>
              {lead.notes && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <span className="text-gray-500 text-sm">Notes:</span>
                  <p className="text-sm text-gray-800 mt-1">{lead.notes}</p>
                </div>
              )}
            </div>

            {/* Update Stage + College + Course */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Update Lead</h3>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="label">Stage</label>
                  <select className="input" value={editStage} onChange={(e) => setEditStage(e.target.value)}>
                    {STAGES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">College</label>
                  <select className="input" value={editCollege} onChange={(e) => { setEditCollege(e.target.value); setEditCourse(''); }}>
                    <option value="">Select college</option>
                    {colleges?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Course</label>
                  <select className="input" value={editCourse} onChange={(e) => setEditCourse(e.target.value)} disabled={!editCollege}>
                    <option value="">Select course</option>
                    {courses?.map((c: any) => <option key={c.id} value={c.id}>{c.name} — {formatCurrency(c.fees)}</option>)}
                  </select>
                </div>
              </div>

              {/* Live incentive preview */}
              {incentivePreview && (
                <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
                  <Calculator className="w-4 h-4 text-green-600 flex-shrink-0" />
                  <div className="text-sm">
                    <span className="text-green-800 font-medium">Incentive: </span>
                    <span className="text-green-700 font-bold">{formatCurrency(incentivePreview.incentiveAmount)}</span>
                    <span className="text-green-600 text-xs ml-2">({incentivePreview.breakdown})</span>
                  </div>
                </div>
              )}

              {editStage === 'WON' && (!editCollege || !editCourse) && (
                <div className="mt-3 flex items-center gap-2 text-amber-700 text-sm bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <AlertTriangle className="w-4 h-4" /> College and Course are required to mark as WON
                </div>
              )}

              <button onClick={handleUpdate} disabled={updateMutation.isPending}
                className="btn-primary mt-4 flex items-center gap-2 text-sm">
                <Save className="w-4 h-4" /> Save Changes
              </button>
            </div>

            {/* Add Note */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                <MessageSquare className="w-4 h-4" /> Add Note
              </h3>
              <textarea className="input resize-none h-24" placeholder="Type a note, call summary, follow-up reminder..."
                value={note} onChange={(e) => setNote(e.target.value)} />
              <button onClick={() => noteMutation.mutate()} disabled={!note.trim() || noteMutation.isPending}
                className="btn-primary mt-2 text-sm">Add Note</button>
            </div>

            {/* Activity Log */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-4">Activity Log</h3>
              <div className="space-y-3">
                {(lead.activities || []).length === 0 ? (
                  <p className="text-sm text-gray-500">No activities yet</p>
                ) : (
                  lead.activities.map((act: any) => (
                    <div key={act.id} className="flex gap-3 text-sm">
                      <span className="text-lg flex-shrink-0">{activityIcon[act.type] || '📌'}</span>
                      <div className="flex-1">
                        <div className="text-gray-800">{act.content}</div>
                        <div className="text-xs text-gray-400 mt-0.5">
                          {act.user?.name} · {formatRelative(act.createdAt)}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Right: Incentive + SLA Panel */}
          <div className="space-y-4">
            {/* Incentive Card */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-3">💰 Incentive</h3>
              {lead.incentiveAmount ? (
                <div>
                  <div className="text-3xl font-bold text-green-700">{formatCurrency(lead.incentiveAmount)}</div>
                  <div className="text-xs text-gray-500 mt-1">Source: {lead.incentiveSource}</div>
                  {lead.feesAtClosure && (
                    <div className="text-xs text-gray-500 mt-0.5">Fees at closure: {formatCurrency(lead.feesAtClosure)}</div>
                  )}
                </div>
              ) : (
                <div className="text-gray-400 text-sm">
                  {lead.college && lead.course ? 'Calculating...' : 'Select college + course to auto-calculate'}
                </div>
              )}
            </div>

            {/* SLA Card */}
            <div className="card p-5">
              <h3 className="font-semibold text-gray-800 mb-3">⏱ SLA Status</h3>
              {sla ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Status</span>
                    <SlaBadge isBreached={sla.isBreached} daysRemaining={sla.daysRemaining} />
                  </div>
                  {sla.slaApplicable && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Days in stage</span>
                        <span className="font-medium">{sla.daysSinceStageStart}d</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">SLA limit</span>
                        <span className="font-medium">{sla.slaLimitDays}d</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Days remaining</span>
                        <span className={`font-medium ${sla.daysRemaining <= 0 ? 'text-red-600' : sla.daysRemaining <= 2 ? 'text-amber-600' : 'text-green-600'}`}>
                          {sla.daysRemaining <= 0 ? `${Math.abs(sla.daysRemaining)}d overdue` : `${sla.daysRemaining}d`}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              ) : <div className="text-sm text-gray-400">Loading...</div>}
            </div>

            {/* College/Course Summary */}
            {lead.college && (
              <div className="card p-5">
                <h3 className="font-semibold text-gray-800 mb-3">🏫 College</h3>
                <div className="text-sm space-y-1">
                  <div className="font-medium text-gray-800">{lead.college.name}</div>
                  {lead.college.city && <div className="text-gray-500">{lead.college.city}</div>}
                  {lead.course && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="text-gray-800">{lead.course.name}</div>
                      <div className="text-primary-600 font-bold mt-1">{formatCurrency(lead.course.fees)}</div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
