'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { leadsApi, collegesApi, coursesApi, usersApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { StageBadge, SourceBadge, SlaBadge, EmptyState, LoadingSpinner, Pagination, Modal } from '@/components/ui';
import { useAuth } from '@/lib/auth';
import { formatCurrency, formatDate, daysSince, downloadBlob } from '@/lib/utils';
import toast from 'react-hot-toast';
import { Plus, Search, Filter, Download, RefreshCw, Edit2, Eye } from 'lucide-react';
import Link from 'next/link';
import { CreateLeadModal } from '@/components/leads/CreateLeadModal';

const STAGES = ['', 'INITIATED', 'IN_PROGRESS', 'WON', 'LOST'];
const SOURCES = ['', 'MANUAL', 'SULEKHA', 'WEBSITE', 'REFERRAL'];

export default function LeadsPage() {
  const { isAdmin } = useAuth();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [stage, setStage] = useState('');
  const [source, setSource] = useState('');
  const [slaBreach, setSlaBreach] = useState('');
  const [showCreate, setShowCreate] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['leads', page, search, stage, source, slaBreach],
    queryFn: () => leadsApi.list({
      page, limit: 20, search: search || undefined,
      stage: stage || undefined, source: source || undefined,
      slaBreach: slaBreach ? slaBreach === 'true' : undefined,
    }).then((r) => r.data),
  });

  const exportMutation = useMutation({
    mutationFn: () => import('@/lib/api').then(({ excelApi }) => excelApi.exportLeads()),
    onSuccess: (res) => {
      downloadBlob(new Blob([res.data]), `leads-${Date.now()}.xlsx`);
      toast.success('Leads exported!');
    },
  });

  const leads = data?.data || [];
  const meta = data?.meta;

  return (
    <AppLayout title="Leads / CRM">
      <div className="space-y-4">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-60">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="input pl-9" placeholder="Search by name, phone, email..."
              value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>

          {/* Filters */}
          <select className="input w-36" value={stage} onChange={(e) => { setStage(e.target.value); setPage(1); }}>
            <option value="">All Stages</option>
            {STAGES.filter(Boolean).map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
          </select>
          <select className="input w-32" value={source} onChange={(e) => { setSource(e.target.value); setPage(1); }}>
            <option value="">All Sources</option>
            {SOURCES.filter(Boolean).map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <select className="input w-32" value={slaBreach} onChange={(e) => { setSlaBreach(e.target.value); setPage(1); }}>
            <option value="">SLA Status</option>
            <option value="true">Breached</option>
            <option value="false">On Track</option>
          </select>

          <div className="flex items-center gap-2 ml-auto">
            <button onClick={() => exportMutation.mutate()}
              className="btn-secondary flex items-center gap-2 text-sm">
              <Download className="w-4 h-4" /> Export
            </button>
            {(isAdmin || true) && (
              <button onClick={() => setShowCreate(true)}
                className="btn-primary flex items-center gap-2 text-sm">
                <Plus className="w-4 h-4" /> Add Lead
              </button>
            )}
          </div>
        </div>

        {/* Summary bar */}
        {meta && (
          <div className="text-sm text-gray-500">
            Showing {leads.length} of {meta.total} leads
          </div>
        )}

        {/* Table */}
        <div className="card overflow-hidden">
          {isLoading ? (
            <LoadingSpinner />
          ) : leads.length === 0 ? (
            <EmptyState title="No leads found" description="Try adjusting your filters or add a new lead"
              action={<button onClick={() => setShowCreate(true)} className="btn-primary text-sm">Add Lead</button>} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    {['Name', 'Phone', 'Interest', 'College / Course', 'Stage', 'Source', 'SLA', 'Incentive', 'Assigned', 'Created', ''].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {leads.map((lead: any) => (
                    <tr key={lead.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800">{lead.name}</div>
                        {lead.email && <div className="text-xs text-gray-500">{lead.email}</div>}
                      </td>
                      <td className="px-4 py-3 text-gray-700">{lead.phone}</td>
                      <td className="px-4 py-3">
                        <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-medium">{lead.courseInterested}</span>
                      </td>
                      <td className="px-4 py-3">
                        {lead.college ? (
                          <div>
                            <div className="text-gray-800 text-xs font-medium">{lead.college.name}</div>
                            <div className="text-gray-500 text-xs">{lead.course?.name || '—'}</div>
                          </div>
                        ) : (
                          <span className="text-gray-400 text-xs">Not selected</span>
                        )}
                      </td>
                      <td className="px-4 py-3"><StageBadge stage={lead.stage} /></td>
                      <td className="px-4 py-3"><SourceBadge source={lead.source} /></td>
                      <td className="px-4 py-3">
                        <SlaBadge isBreached={lead.slaBreach} />
                        {lead.slaBreach && (
                          <div className="text-xs text-red-500 mt-0.5">{daysSince(lead.stageStartDate)}d in {lead.stage.replace('_',' ')}</div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {lead.incentiveAmount ? (
                          <div>
                            <div className="text-green-700 font-medium">{formatCurrency(lead.incentiveAmount)}</div>
                            <div className="text-xs text-gray-400">{lead.incentiveSource}</div>
                          </div>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-600">{lead.assignedUser?.name || 'Unassigned'}</td>
                      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{formatDate(lead.createdAt)}</td>
                      <td className="px-4 py-3">
                        <Link href={`/leads/${lead.id}`}
                          className="inline-flex items-center gap-1 text-primary-600 hover:text-primary-800 text-xs font-medium">
                          <Eye className="w-3.5 h-3.5" /> View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pagination */}
        {meta && <Pagination page={meta.page} totalPages={meta.totalPages} onPage={setPage} />}
      </div>

      {/* Create Lead Modal */}
      {showCreate && <CreateLeadModal onClose={() => setShowCreate(false)} onSuccess={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['leads'] }); }} />}
    </AppLayout>
  );
}
