'use client';
import { useQuery } from '@tanstack/react-query';
import { leadsApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { SlaBadge, LoadingSpinner, EmptyState } from '@/components/ui';
import { formatDate } from '@/lib/utils';
import Link from 'next/link';
import { AlertTriangle, Clock, CheckCircle } from 'lucide-react';

export default function SlaPage() {
  const { data: report, isLoading } = useQuery({
    queryKey: ['sla-report'],
    queryFn: () => leadsApi.slaReport().then((r) => r.data),
    refetchInterval: 60000,
  });

  const breached = report?.filter((l: any) => l.status === 'BREACHED') || [];
  const nearBreach = report?.filter((l: any) => l.status === 'NEAR_BREACH') || [];
  const onTrack = report?.filter((l: any) => l.status === 'ON_TRACK') || [];

  return (
    <AppLayout title="SLA Monitor">
      <div className="space-y-6">
        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-4">
          <div className="card p-5 border-l-4 border-red-500">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-red-500" />
              <div>
                <div className="text-2xl font-bold text-red-600">{breached.length}</div>
                <div className="text-sm text-gray-600">SLA Breached</div>
              </div>
            </div>
          </div>
          <div className="card p-5 border-l-4 border-amber-500">
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-amber-500" />
              <div>
                <div className="text-2xl font-bold text-amber-600">{nearBreach.length}</div>
                <div className="text-sm text-gray-600">Near Breach (≤2 days)</div>
              </div>
            </div>
          </div>
          <div className="card p-5 border-l-4 border-green-500">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <div>
                <div className="text-2xl font-bold text-green-600">{onTrack.length}</div>
                <div className="text-sm text-gray-600">On Track</div>
              </div>
            </div>
          </div>
        </div>

        {isLoading ? <LoadingSpinner /> : (
          <>
            {/* Breached */}
            {breached.length > 0 && (
              <div className="card overflow-hidden">
                <div className="px-5 py-3 bg-red-50 border-b border-red-100 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <h3 className="font-semibold text-red-800">SLA Breached ({breached.length})</h3>
                </div>
                <SlaTable leads={breached} />
              </div>
            )}

            {/* Near Breach */}
            {nearBreach.length > 0 && (
              <div className="card overflow-hidden">
                <div className="px-5 py-3 bg-amber-50 border-b border-amber-100 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <h3 className="font-semibold text-amber-800">Near Breach — Act Now ({nearBreach.length})</h3>
                </div>
                <SlaTable leads={nearBreach} />
              </div>
            )}

            {/* On Track */}
            <div className="card overflow-hidden">
              <div className="px-5 py-3 bg-green-50 border-b border-green-100 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <h3 className="font-semibold text-green-800">On Track ({onTrack.length})</h3>
              </div>
              {onTrack.length === 0 ? (
                <EmptyState title="No active leads on track" />
              ) : (
                <SlaTable leads={onTrack} />
              )}
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
}

function SlaTable({ leads }: { leads: any[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 border-b">
          <tr>
            {['Lead', 'Phone', 'Stage', 'Days in Stage', 'SLA Limit', 'Days Left', 'Assigned To', 'College', ''].map((h) => (
              <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {leads.map((lead: any) => (
            <tr key={lead.id} className="hover:bg-gray-50">
              <td className="px-4 py-3 font-medium text-gray-800">{lead.name}</td>
              <td className="px-4 py-3 text-gray-600">{lead.phone}</td>
              <td className="px-4 py-3">
                <span className="text-xs font-medium bg-gray-100 text-gray-700 px-2 py-0.5 rounded">
                  {lead.stage.replace('_', ' ')}
                </span>
              </td>
              <td className="px-4 py-3 font-medium">{lead.daysSinceStageStart}d</td>
              <td className="px-4 py-3 text-gray-500">{lead.slaLimitDays}d</td>
              <td className="px-4 py-3">
                <span className={`font-semibold ${lead.daysRemaining <= 0 ? 'text-red-600' : lead.daysRemaining <= 2 ? 'text-amber-600' : 'text-green-600'}`}>
                  {lead.daysRemaining <= 0 ? `${Math.abs(lead.daysRemaining)}d overdue` : `${lead.daysRemaining}d`}
                </span>
              </td>
              <td className="px-4 py-3 text-gray-600">{lead.assignedUser?.name || 'Unassigned'}</td>
              <td className="px-4 py-3 text-gray-500 text-xs">{lead.college || '—'}</td>
              <td className="px-4 py-3">
                <Link href={`/leads/${lead.id}`} className="text-primary-600 hover:underline text-xs font-medium">View →</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
