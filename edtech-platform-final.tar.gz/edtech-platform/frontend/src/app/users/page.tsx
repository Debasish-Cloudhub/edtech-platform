'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { usersApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { EmptyState, LoadingSpinner, Modal } from '@/components/ui';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';
import { Plus, UserX, Loader2 } from 'lucide-react';

const ROLES = ['ADMIN', 'SUPER_ADMIN', 'SALES_AGENT', 'COUNSELOR', 'FINANCE_MANAGER', 'STUDENT'];
const ROLE_COLORS: Record<string, string> = {
  SUPER_ADMIN: 'bg-purple-100 text-purple-800',
  ADMIN: 'bg-indigo-100 text-indigo-800',
  SALES_AGENT: 'bg-blue-100 text-blue-800',
  COUNSELOR: 'bg-cyan-100 text-cyan-800',
  FINANCE_MANAGER: 'bg-amber-100 text-amber-800',
  STUDENT: 'bg-gray-100 text-gray-700',
};

export default function UsersPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [roleFilter, setRoleFilter] = useState('');

  const { data: users, isLoading } = useQuery({
    queryKey: ['users', roleFilter],
    queryFn: () => usersApi.list(roleFilter || undefined).then((r) => r.data),
  });

  const deactivateMutation = useMutation({
    mutationFn: (id: string) => usersApi.deactivate(id),
    onSuccess: () => { toast.success('User deactivated'); qc.invalidateQueries({ queryKey: ['users'] }); },
  });

  return (
    <AppLayout title="Users">
      <div className="space-y-5">
        <div className="flex items-center gap-3">
          <select className="input w-44" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
            <option value="">All Roles</option>
            {ROLES.map((r) => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
          </select>
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2 text-sm ml-auto">
            <Plus className="w-4 h-4" /> Add User
          </button>
        </div>

        <div className="card overflow-hidden">
          {isLoading ? <LoadingSpinner /> : users?.length === 0 ? (
            <EmptyState title="No users found" />
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  {['Name', 'Email', 'Phone', 'Role', 'Leads', 'Status', 'Joined', 'Actions'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users?.map((user: any) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center text-xs font-bold text-primary-700">
                          {user.name?.charAt(0)?.toUpperCase()}
                        </div>
                        <span className="font-medium text-gray-800">{user.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{user.email}</td>
                    <td className="px-4 py-3 text-gray-600">{user.phone || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${ROLE_COLORS[user.role] || 'bg-gray-100 text-gray-700'}`}>
                        {user.role.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{user._count?.assignedLeads || 0}</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-700'}`}>
                        {user.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDate(user.createdAt)}</td>
                    <td className="px-4 py-3">
                      {user.isActive && (
                        <button onClick={() => { if (confirm(`Deactivate ${user.name}?`)) deactivateMutation.mutate(user.id); }}
                          className="text-red-500 hover:text-red-700 p-1 rounded" title="Deactivate">
                          <UserX className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showCreate && (
        <CreateUserModal
          onClose={() => setShowCreate(false)}
          onSuccess={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['users'] }); }}
        />
      )}
    </AppLayout>
  );
}

function CreateUserModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState({ name: '', email: '', password: 'Test@1234', phone: '', role: 'SALES_AGENT' });

  const createMutation = useMutation({
    mutationFn: (data: any) => usersApi.create(data),
    onSuccess: () => { toast.success('User created!'); onSuccess(); },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed to create user'),
  });

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Modal open onClose={onClose} title="Create New User">
      <div className="space-y-4">
        <div>
          <label className="label">Full Name *</label>
          <input className="input" value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="John Doe" />
        </div>
        <div>
          <label className="label">Email *</label>
          <input className="input" type="email" value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="john@company.com" />
        </div>
        <div>
          <label className="label">Password *</label>
          <input className="input" value={form.password} onChange={(e) => set('password', e.target.value)} />
        </div>
        <div>
          <label className="label">Phone</label>
          <input className="input" value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="9876543210" />
        </div>
        <div>
          <label className="label">Role *</label>
          <select className="input" value={form.role} onChange={(e) => set('role', e.target.value)}>
            {ROLES.map((r) => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
          </select>
        </div>
        <div className="flex justify-end gap-3 pt-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending}
            className="btn-primary flex items-center gap-2">
            {createMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Create User
          </button>
        </div>
      </div>
    </Modal>
  );
}
