'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { collegesApi, coursesApi } from '@/lib/api';
import { QueryProvider } from '@/components/QueryProvider';
import { formatCurrency } from '@/lib/utils';
import { Search, Building2, BookOpen, MapPin, Clock, GraduationCap, ChevronRight } from 'lucide-react';
import Link from 'next/link';

export default function StudentPortalPage() {
  return (
    <QueryProvider>
      <StudentPortalContent />
    </QueryProvider>
  );
}

function StudentPortalContent() {
  const [search, setSearch] = useState('');
  const [countryId, setCountryId] = useState('');
  const [courseType, setCourseType] = useState('');
  const [activeTab, setActiveTab] = useState<'colleges' | 'courses'>('colleges');

  const { data: countries } = useQuery({
    queryKey: ['countries'],
    queryFn: () => collegesApi.countries().then((r) => r.data),
  });

  const { data: colleges, isLoading: loadingColleges } = useQuery({
    queryKey: ['colleges', countryId, search],
    queryFn: () => collegesApi.list({ countryId: countryId || undefined, search: search || undefined }).then((r) => r.data),
    enabled: activeTab === 'colleges',
  });

  const { data: courses, isLoading: loadingCourses } = useQuery({
    queryKey: ['courses', search, courseType, countryId],
    queryFn: () => coursesApi.list({
      search: search || undefined,
      courseType: courseType || undefined,
      countryId: countryId || undefined,
    }).then((r) => r.data),
    enabled: activeTab === 'courses',
  });

  const { data: courseTypes } = useQuery({
    queryKey: ['course-types'],
    queryFn: () => coursesApi.types().then((r) => r.data),
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Header */}
      <header className="bg-gradient-to-r from-primary-900 to-primary-600 text-white">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-primary-600" />
              </div>
              <div>
                <div className="font-bold text-lg">EduConsult</div>
                <div className="text-primary-200 text-xs">Your gateway to top colleges</div>
              </div>
            </div>
            <Link href="/login" className="bg-white text-primary-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary-50">
              Sign In
            </Link>
          </div>

          <div className="text-center py-6">
            <h1 className="text-4xl font-bold mb-3">Find Your Dream College</h1>
            <p className="text-primary-200 text-lg mb-8">
              Explore BTech, MBA & more — India, USA, UK, Canada, Germany and beyond
            </p>

            {/* Search bar */}
            <div className="max-w-2xl mx-auto flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  className="w-full pl-12 pr-4 py-3 rounded-xl text-gray-900 text-base focus:outline-none focus:ring-2 focus:ring-white/50"
                  placeholder="Search colleges, courses, countries..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <select
                className="px-4 py-3 rounded-xl text-gray-700 focus:outline-none bg-white"
                value={countryId}
                onChange={(e) => setCountryId(e.target.value)}
              >
                <option value="">All Countries</option>
                {countries?.map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Stats bar */}
          <div className="flex justify-center gap-12 py-4 border-t border-primary-700/50">
            {[
              { label: 'Colleges', value: colleges?.length || '50+' },
              { label: 'Countries', value: countries?.length || '10+' },
              { label: 'Courses', value: courses?.length || '100+' },
              { label: 'Students Placed', value: '2000+' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-primary-300 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('colleges')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-sm transition-colors ${
              activeTab === 'colleges'
                ? 'bg-primary-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <Building2 className="w-4 h-4" /> Colleges
          </button>
          <button
            onClick={() => setActiveTab('courses')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-sm transition-colors ${
              activeTab === 'courses'
                ? 'bg-primary-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <BookOpen className="w-4 h-4" /> Courses
          </button>

          {activeTab === 'courses' && (
            <div className="ml-auto">
              <select
                className="border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-700 bg-white"
                value={courseType}
                onChange={(e) => setCourseType(e.target.value)}
              >
                <option value="">All Types</option>
                {courseTypes?.map((t: any) => (
                  <option key={t.courseType} value={t.courseType}>{t.courseType}</option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Colleges Grid */}
        {activeTab === 'colleges' && (
          <>
            {loadingColleges ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-xl p-5 animate-pulse">
                    <div className="h-5 bg-gray-200 rounded w-3/4 mb-3" />
                    <div className="h-4 bg-gray-100 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {colleges?.map((college: any) => (
                  <Link
                    key={college.id}
                    href={`/colleges/${college.id}`}
                    className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-md hover:border-primary-200 transition-all group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-primary-600" />
                      </div>
                      <span className="text-xs font-bold bg-gray-100 text-gray-500 px-2 py-1 rounded-lg">
                        {college.country?.code}
                      </span>
                    </div>
                    <h3 className="font-semibold text-gray-900 group-hover:text-primary-700 transition-colors">
                      {college.name}
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1 text-sm text-gray-500">
                      <MapPin className="w-3.5 h-3.5" />
                      {college.city ? `${college.city}, ` : ''}{college.country?.name}
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                      <span className="text-xs text-gray-500">
                        {college._count?.courses || 0} courses
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-primary-600 transition-colors" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}

        {/* Courses Table */}
        {activeTab === 'courses' && (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            {loadingCourses ? (
              <div className="p-8 text-center text-gray-500">Loading courses...</div>
            ) : !courses?.length ? (
              <div className="p-16 text-center text-gray-500">No courses found. Try adjusting your filters.</div>
            ) : (
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    {['Course', 'College', 'Country', 'Type', 'Duration', 'Total Fees'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {courses.map((course: any) => (
                    <tr key={course.id} className="hover:bg-gray-50">
                      <td className="px-4 py-4 font-medium text-gray-900">{course.name}</td>
                      <td className="px-4 py-4">
                        <Link href={`/colleges/${course.college?.id}`}
                          className="text-primary-600 hover:underline font-medium">
                          {course.college?.name}
                        </Link>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-1.5 text-gray-600">
                          <MapPin className="w-3.5 h-3.5" />
                          {course.college?.country?.name}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="bg-indigo-50 text-indigo-700 text-xs font-medium px-2.5 py-1 rounded-full">
                          {course.courseType}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-gray-600">
                        {course.duration ? (
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5" />{course.duration}
                          </div>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-4">
                        <div className="font-bold text-primary-700 text-base">
                          {formatCurrency(course.fees, course.currency)}
                        </div>
                        <div className="text-xs text-gray-400">{course.currency || 'INR'}</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* CTA Section */}
        <div className="mt-12 bg-gradient-to-r from-primary-600 to-primary-800 rounded-2xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-2">Ready to Begin Your Journey?</h2>
          <p className="text-primary-200 mb-6">
            Our expert counselors will guide you from shortlisting to admission.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <a href="tel:+91-1234567890"
              className="bg-white text-primary-700 px-6 py-3 rounded-xl font-semibold hover:bg-primary-50 transition-colors">
              📞 Call Us Now
            </a>
            <a href="https://wa.me/911234567890"
              className="bg-green-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-600 transition-colors">
              💬 WhatsApp
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 text-sm text-center py-6 mt-12">
        <p>© {new Date().getFullYear()} EduConsult — BTech & MBA Admissions Consulting</p>
      </footer>
    </div>
  );
}
