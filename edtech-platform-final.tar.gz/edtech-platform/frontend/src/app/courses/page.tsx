'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { coursesApi, collegesApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { EmptyState, LoadingSpinner } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';
import { Search, Clock, MapPin } from 'lucide-react';
import Link from 'next/link';

export default function CoursesPage() {
  const [search, setSearch] = useState('');
  const [courseType, setCourseType] = useState('');
  const [countryId, setCountryId] = useState('');

  const { data: types } = useQuery({ queryKey: ['course-types'], queryFn: () => coursesApi.types().then((r) => r.data) });
  const { data: countries } = useQuery({ queryKey: ['countries'], queryFn: () => collegesApi.countries().then((r) => r.data) });

  const { data: courses, isLoading } = useQuery({
    queryKey: ['courses', search, courseType, countryId],
    queryFn: () => coursesApi.list({
      search: search || undefined,
      courseType: courseType || undefined,
      countryId: countryId || undefined,
    }).then((r) => r.data),
  });

  return (
    <AppLayout title="Courses">
      <div className="space-y-5">
        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-60">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input className="input pl-9" placeholder="Search courses or colleges..." value={search}
              onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select className="input w-36" value={courseType} onChange={(e) => setCourseType(e.target.value)}>
            <option value="">All Types</option>
            {types?.map((t: any) => <option key={t.courseType} value={t.courseType}>{t.courseType} ({t.count})</option>)}
          </select>
          <select className="input w-40" value={countryId} onChange={(e) => setCountryId(e.target.value)}>
            <option value="">All Countries</option>
            {countries?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        {courses && <div className="text-sm text-gray-500">{courses.length} courses found</div>}

        {isLoading ? <LoadingSpinner /> : courses?.length === 0 ? (
          <EmptyState title="No courses found" />
        ) : (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    {['Course', 'College', 'Country', 'Type', 'Duration', 'Fees'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {courses?.map((course: any) => (
                    <tr key={course.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-800">{course.name}</div>
                      </td>
                      <td className="px-4 py-3">
                        <Link href={`/colleges/${course.college?.id}`}
                          className="text-primary-600 hover:underline">{course.college?.name}</Link>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 text-gray-600">
                          <MapPin className="w-3.5 h-3.5" />
                          {course.college?.country?.name}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-medium">{course.courseType}</span>
                      </td>
                      <td className="px-4 py-3">
                        {course.duration ? (
                          <div className="flex items-center gap-1.5 text-gray-600">
                            <Clock className="w-3.5 h-3.5" />{course.duration}
                          </div>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-bold text-primary-700">{formatCurrency(course.fees, course.currency)}</div>
                        <div className="text-xs text-gray-400">{course.currency || 'INR'}</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
