'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { collegesApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { EmptyState, LoadingSpinner } from '@/components/ui';
import { Search, Building2, MapPin, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function CollegesPage() {
  const [search, setSearch] = useState('');
  const [countryId, setCountryId] = useState('');

  const { data: countries } = useQuery({
    queryKey: ['countries'],
    queryFn: () => collegesApi.countries().then((r) => r.data),
  });

  const { data: colleges, isLoading } = useQuery({
    queryKey: ['colleges', countryId, search],
    queryFn: () => collegesApi.list({ countryId: countryId || undefined, search: search || undefined }).then((r) => r.data),
  });

  return (
    <AppLayout title="Colleges">
      <div className="space-y-5">
        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-60">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input className="input pl-9" placeholder="Search colleges..." value={search}
              onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select className="input w-44" value={countryId} onChange={(e) => setCountryId(e.target.value)}>
            <option value="">All Countries</option>
            {countries?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        {/* Results count */}
        {colleges && (
          <div className="text-sm text-gray-500">{colleges.length} college{colleges.length !== 1 ? 's' : ''} found</div>
        )}

        {/* Grid */}
        {isLoading ? <LoadingSpinner /> : (
          colleges?.length === 0 ? (
            <EmptyState title="No colleges found" description="Try adjusting your search or filters" />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {colleges?.map((college: any) => (
                <Link key={college.id} href={`/colleges/${college.id}`}
                  className="card p-5 hover:shadow-md transition-shadow cursor-pointer block">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Building2 className="w-5 h-5 text-primary-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate">{college.name}</h3>
                      <div className="flex items-center gap-1.5 mt-1 text-sm text-gray-500">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{college.city ? `${college.city}, ` : ''}{college.country?.name}</span>
                      </div>
                    </div>
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full flex-shrink-0">
                      {college.country?.code}
                    </span>
                  </div>
                  <div className="mt-3 pt-3 border-t border-gray-100 flex items-center gap-1.5 text-sm text-gray-500">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{college._count?.courses || 0} course{college._count?.courses !== 1 ? 's' : ''}</span>
                  </div>
                </Link>
              ))}
            </div>
          )
        )}
      </div>
    </AppLayout>
  );
}
