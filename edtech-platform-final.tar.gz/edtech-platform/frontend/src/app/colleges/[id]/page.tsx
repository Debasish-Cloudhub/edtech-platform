'use client';
import { useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { collegesApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { LoadingSpinner } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';
import Link from 'next/link';
import { ArrowLeft, MapPin, Globe, BookOpen, Clock, DollarSign } from 'lucide-react';

export default function CollegeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { data: college, isLoading } = useQuery({
    queryKey: ['college', id],
    queryFn: () => collegesApi.get(id).then((r) => r.data),
  });

  if (isLoading) return <AppLayout title="College"><LoadingSpinner /></AppLayout>;
  if (!college) return <AppLayout title="College"><div className="text-center py-20 text-gray-500">College not found</div></AppLayout>;

  const coursesByType = college.courses?.reduce((acc: any, c: any) => {
    if (!acc[c.courseType]) acc[c.courseType] = [];
    acc[c.courseType].push(c);
    return acc;
  }, {}) || {};

  return (
    <AppLayout title={college.name}>
      <div className="max-w-4xl mx-auto space-y-6">
        <Link href="/colleges" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
          <ArrowLeft className="w-4 h-4" /> Back to Colleges
        </Link>

        {/* Header */}
        <div className="card p-6">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{college.name}</h2>
              <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-gray-600">
                {college.city && (
                  <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" />{college.city}</span>
                )}
                <span className="flex items-center gap-1.5">
                  <Globe className="w-4 h-4" />{college.country?.name}
                </span>
                {college.website && (
                  <a href={college.website} target="_blank" rel="noopener noreferrer"
                    className="text-primary-600 hover:underline flex items-center gap-1.5">
                    <Globe className="w-4 h-4" />Visit Website
                  </a>
                )}
              </div>
              {college.description && (
                <p className="mt-3 text-gray-600 text-sm">{college.description}</p>
              )}
            </div>
            <span className="text-lg font-bold text-gray-400 bg-gray-100 px-3 py-1 rounded-lg">
              {college.country?.code}
            </span>
          </div>
        </div>

        {/* Courses by type */}
        {Object.keys(coursesByType).length === 0 ? (
          <div className="card p-8 text-center text-gray-500">No courses available yet</div>
        ) : (
          Object.entries(coursesByType).map(([type, courses]: [string, any]) => (
            <div key={type} className="card overflow-hidden">
              <div className="px-5 py-3 bg-gray-50 border-b flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-primary-600" />
                <h3 className="font-semibold text-gray-800">{type} Programs</h3>
                <span className="ml-auto text-xs text-gray-500">{courses.length} course{courses.length !== 1 ? 's' : ''}</span>
              </div>
              <div className="divide-y divide-gray-50">
                {courses.map((course: any) => (
                  <div key={course.id} className="px-5 py-4 flex items-center justify-between hover:bg-gray-50">
                    <div>
                      <div className="font-medium text-gray-800">{course.name}</div>
                      <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                        {course.duration && (
                          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{course.duration}</span>
                        )}
                        <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">{course.courseType}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-primary-700 text-lg">{formatCurrency(course.fees, course.currency)}</div>
                      <div className="text-xs text-gray-400">{course.currency || 'INR'} · Total fees</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </AppLayout>
  );
}
