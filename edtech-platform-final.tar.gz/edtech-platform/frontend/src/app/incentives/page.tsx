'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { leadsApi, usersApi } from '@/lib/api';
import { AppLayout } from '@/components/layout/AppLayout';
import { LoadingSpinner, EmptyState } from '@/components/ui';
import { formatCurrency, formatDate } from '@/lib/utils';
import { DollarSign, TrendingUp, Users, Filter } from 'lucide-react';

export default function IncentivesPage() {
  const [filterUserId, setFilterUserId] = useState('');

  const { data: agents } = useQuery({
    queryKey: ['agents'],
    queryFn: () => usersApi.salesAgents().then((r) => r.data),
  });

  const { data: summary, isLoading } = useQuery({
    queryKey: ['incentive-summary', filterUserId],
    queryFn: () => leadsApi.incentiveSummary(filterUserId || undefined).then((r) => r.data),
  });

  if (isLoading) return <AppLayout title="Incentive Payouts"><LoadingSpinner /></AppLayout>;

  const s = summary || {};

  return (
    <AppLayout title="Incentive Payouts">
      <div className="space-y-6">

        {/* Filter */}
        <div className="flex items-center gap-3">
          <Filter className="w-4 h-4 text-gray-400" />
          <select className="input w-52" value={filterUserId} onChange={(e) => setFilterUserId(e.target.value)}>
            <option value="">All Sales Agents</option>
            {agents?.map((a: any) => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="card p-5">
            <div className="text-2xl font-bold text-green-700">{formatCurrency(s.totalIncentive)}</div>
            <div className="text-sm text-gray-500 mt-1">Total Incentives</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-blue-700">{formatCurrency(s.totalFees)}</div>
            <div className="text-sm text-gray-500 mt-1">Total Fees Collected</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-indigo-700">{s.totalWon || 0}</div>
            <div className="text-sm text-gray-500 mt-1">Won Leads</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-purple-700">
              {s.totalFees > 0 ? ((s.totalIncentive / s.totalFees) * 100).toFixed(1) : 0}%
            </div>
            <div className="text-sm text-gray-500 mt-1">Avg Incentive Rate</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* By Agent */}
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-500" />
              <h3 className="font-semibold text-gray-800">Incentives by Agent</h3>
            </div>
            {!s.byUser?.length ? (
              <EmptyState title="No payouts yet" />
            ) : (
              <div className="divide-y divide-gray-100">
                {s.byUser.map((agent: any, i: number) => (
                  <div key={i} className="px-5 py-4 flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center text-xs font-bold text-primary-700 flex-shrink-0">
                      {i + 1}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-800">{agent.name}</div>
                      <div className="text-xs text-gray-500">{agent.count} won lead{agent.count !== 1 ? 's' : ''}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-700">{formatCurrency(agent.totalIncentive)}</div>
                      {agent.count > 0 && (
                        <div className="text-xs text-gray-400">
                          avg {formatCurrency(agent.totalIncentive / agent.count)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* By Source */}
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-500" />
              <h3 className="font-semibold text-gray-800">Incentive Source Breakdown</h3>
            </div>
            <div className="p-5 space-y-3">
              {Object.entries(s.bySource || {}).map(([source, count]: [string, any]) => {
                const colors: Record<string, string> = {
                  EXCEL: 'bg-green-500', CALCULATED: 'bg-blue-500', MANUAL: 'bg-gray-400',
                };
                const total = Object.values(s.bySource || {}).reduce((a: number, b: any) => a + b, 0);
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                return (
                  <div key={source}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium text-gray-700">{source}</span>
                      <span className="text-gray-500">{count} leads ({pct}%)</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className={`${colors[source] || 'bg-gray-400'} h-2 rounded-full`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Individual Won Leads Table */}
        <div className="card overflow-hidden">
          <div className="px-5 py-4 border-b flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-green-500" />
            <h3 className="font-semibold text-gray-800">Won Leads — Incentive Detail</h3>
          </div>
          {!s.leads?.length ? (
            <EmptyState title="No won leads yet" description="Mark leads as WON to see incentive payouts here" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    {['Lead', 'College', 'Course', 'Fees Closed', 'Incentive', 'Source', 'Agent', 'Date'].map((h) => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {s.leads.map((lead: any) => (
                    <tr key={lead.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-800">{lead.name}</td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{lead.college?.name || '—'}</td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{lead.course?.name || '—'}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">{formatCurrency(lead.feesAtClosure)}</td>
                      <td className="px-4 py-3">
                        <span className="font-bold text-green-700">{formatCurrency(lead.incentiveAmount)}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`badge text-xs ${
                          lead.incentiveSource === 'EXCEL' ? 'bg-green-100 text-green-700' :
                          lead.incentiveSource === 'CALCULATED' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {lead.incentiveSource || '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{lead.assignedUser?.name || 'Unassigned'}</td>
                      <td className="px-4 py-3 text-gray-400 text-xs whitespace-nowrap">{formatDate(lead.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
                {/* Totals row */}
                <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                  <tr>
                    <td colSpan={3} className="px-4 py-3 font-bold text-gray-700">TOTAL</td>
                    <td className="px-4 py-3 font-bold text-gray-900">{formatCurrency(s.totalFees)}</td>
                    <td className="px-4 py-3 font-bold text-green-700">{formatCurrency(s.totalIncentive)}</td>
                    <td colSpan={3} />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
