'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Users, FileText, Building2, BookOpen,
  Receipt, Settings, LogOut, GraduationCap, DollarSign,
  RefreshCw, TrendingUp, AlertTriangle,
} from 'lucide-react';

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  roles?: string[];
}

const NAV_ITEMS: NavItem[] = [
  { href: '/dashboard',          label: 'Dashboard',     icon: LayoutDashboard },
  { href: '/leads',              label: 'Leads / CRM',   icon: FileText,        roles: ['ADMIN','SUPER_ADMIN','SALES_AGENT','COUNSELOR'] },
  { href: '/leads/sla',          label: 'SLA Monitor',   icon: AlertTriangle,   roles: ['ADMIN','SUPER_ADMIN'] },
  { href: '/colleges',           label: 'Colleges',      icon: Building2 },
  { href: '/courses',            label: 'Courses',       icon: BookOpen },
  { href: '/expenses',           label: 'Expenses',      icon: Receipt,         roles: ['ADMIN','SUPER_ADMIN','FINANCE_MANAGER','SALES_AGENT','COUNSELOR'] },
  { href: '/users',              label: 'Users',         icon: Users,           roles: ['ADMIN','SUPER_ADMIN'] },
  { href: '/sulekha',            label: 'Sulekha Sync',  icon: RefreshCw,       roles: ['ADMIN','SUPER_ADMIN'] },
  { href: '/incentives', label: 'Incentive Payouts', icon: DollarSign, roles: ['ADMIN','SUPER_ADMIN'] },
  { href: '/analytics',          label: 'Analytics',     icon: TrendingUp,      roles: ['ADMIN','SUPER_ADMIN','FINANCE_MANAGER'] },
  { href: '/settings',           label: 'Settings',      icon: Settings,        roles: ['ADMIN','SUPER_ADMIN'] },
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  const visibleItems = NAV_ITEMS.filter(
    (item) => !item.roles || item.roles.includes(user?.role || ''),
  );

  return (
    <aside className="w-64 h-screen bg-white border-r border-gray-200 flex flex-col fixed left-0 top-0 z-30">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-100">
        <div className="w-9 h-9 bg-primary-600 rounded-xl flex items-center justify-center">
          <GraduationCap className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="font-bold text-gray-900 text-sm">EduConsult</div>
          <div className="text-xs text-gray-500 capitalize">{user?.role?.toLowerCase().replace('_', ' ')}</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link key={item.href} href={item.href}
              className={cn('sidebar-link', active && 'active')}>
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User + Logout */}
      <div className="px-3 py-4 border-t border-gray-100">
        <div className="flex items-center gap-3 px-3 py-2 mb-1">
          <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
            <span className="text-primary-700 font-semibold text-sm">
              {user?.name?.charAt(0)?.toUpperCase()}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-gray-900 truncate">{user?.name}</div>
            <div className="text-xs text-gray-500 truncate">{user?.email}</div>
          </div>
        </div>
        <button onClick={logout}
          className="sidebar-link w-full text-red-600 hover:bg-red-50 hover:text-red-700">
          <LogOut className="w-4 h-4" /> Sign out
        </button>
      </div>
    </aside>
  );
}
