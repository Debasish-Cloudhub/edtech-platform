// ─── Stat Card ──────────────────────────────────────────────────────────────
interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ElementType;
  color?: 'blue' | 'green' | 'yellow' | 'red' | 'purple';
  trend?: { value: string; positive: boolean };
}

const colorMap = {
  blue:   { bg: 'bg-blue-50',   icon: 'text-blue-600',   border: 'border-blue-100' },
  green:  { bg: 'bg-green-50',  icon: 'text-green-600',  border: 'border-green-100' },
  yellow: { bg: 'bg-yellow-50', icon: 'text-yellow-600', border: 'border-yellow-100' },
  red:    { bg: 'bg-red-50',    icon: 'text-red-600',    border: 'border-red-100' },
  purple: { bg: 'bg-purple-50', icon: 'text-purple-600', border: 'border-purple-100' },
};

export function StatCard({ title, value, subtitle, icon: Icon, color = 'blue', trend }: StatCardProps) {
  const c = colorMap[color];
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-gray-500 font-medium">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
          {trend && (
            <div className={`flex items-center gap-1 mt-2 text-xs font-medium ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
              <span>{trend.positive ? '↑' : '↓'}</span>
              <span>{trend.value}</span>
            </div>
          )}
        </div>
        {Icon && (
          <div className={`w-11 h-11 rounded-xl ${c.bg} flex items-center justify-center flex-shrink-0`}>
            <Icon className={`w-5 h-5 ${c.icon}`} />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Stage Badge ─────────────────────────────────────────────────────────────
const stageBadge: Record<string, string> = {
  INITIATED:   'badge-initiated',
  IN_PROGRESS: 'badge bg-amber-100 text-amber-800',
  WON:         'badge-won',
  LOST:        'badge-lost',
};
const stageLabel: Record<string, string> = {
  INITIATED: 'Initiated', IN_PROGRESS: 'In Progress', WON: 'Won', LOST: 'Lost',
};

export function StageBadge({ stage }: { stage: string }) {
  return <span className={stageBadge[stage] || 'badge bg-gray-100 text-gray-700'}>{stageLabel[stage] || stage}</span>;
}

// ─── Source Badge ─────────────────────────────────────────────────────────────
const sourceBadge: Record<string, string> = {
  MANUAL:   'badge bg-gray-100 text-gray-700',
  SULEKHA:  'badge bg-orange-100 text-orange-700',
  WEBSITE:  'badge bg-blue-100 text-blue-700',
  REFERRAL: 'badge bg-purple-100 text-purple-700',
};

export function SourceBadge({ source }: { source: string }) {
  return <span className={sourceBadge[source] || 'badge bg-gray-100 text-gray-600'}>{source}</span>;
}

// ─── SLA Badge ────────────────────────────────────────────────────────────────
export function SlaBadge({ isBreached, daysRemaining }: { isBreached: boolean; daysRemaining?: number }) {
  if (isBreached) return <span className="badge bg-red-100 text-red-700">⚠ Breached</span>;
  if (daysRemaining !== undefined && daysRemaining <= 2) return <span className="badge bg-orange-100 text-orange-700">Near Breach</span>;
  return <span className="badge bg-green-100 text-green-700">On Track</span>;
}

// ─── Empty State ─────────────────────────────────────────────────────────────
export function EmptyState({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="py-16 text-center">
      <div className="text-4xl mb-3">📭</div>
      <h3 className="text-base font-semibold text-gray-700">{title}</h3>
      {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ─── Loading Spinner ──────────────────────────────────────────────────────────
export function LoadingSpinner({ text = 'Loading...' }: { text?: string }) {
  return (
    <div className="flex items-center justify-center py-16 gap-2 text-gray-500">
      <div className="w-5 h-5 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
      <span className="text-sm">{text}</span>
    </div>
  );
}

// ─── Simple Modal ─────────────────────────────────────────────────────────────
interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const sizeMap = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-2xl' };

export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-white rounded-2xl shadow-2xl w-full ${sizeMap[size]} max-h-[90vh] flex flex-col`}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">×</button>
        </div>
        <div className="overflow-y-auto flex-1 px-6 py-4">{children}</div>
      </div>
    </div>
  );
}

// ─── Pagination ───────────────────────────────────────────────────────────────
interface PaginationProps {
  page: number;
  totalPages: number;
  onPage: (p: number) => void;
}

export function Pagination({ page, totalPages, onPage }: PaginationProps) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-center gap-2 py-4">
      <button disabled={page <= 1} onClick={() => onPage(page - 1)}
        className="px-3 py-1.5 text-sm border rounded-lg disabled:opacity-40 hover:bg-gray-50">← Prev</button>
      <span className="text-sm text-gray-600">Page {page} of {totalPages}</span>
      <button disabled={page >= totalPages} onClick={() => onPage(page + 1)}
        className="px-3 py-1.5 text-sm border rounded-lg disabled:opacity-40 hover:bg-gray-50">Next →</button>
    </div>
  );
}
