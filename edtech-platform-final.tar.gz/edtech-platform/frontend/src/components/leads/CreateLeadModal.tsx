'use client';
import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { leadsApi, collegesApi, coursesApi, usersApi } from '@/lib/api';
import { Modal } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';
import toast from 'react-hot-toast';
import { Loader2, Calculator } from 'lucide-react';

interface Props { onClose: () => void; onSuccess: () => void; }

export function CreateLeadModal({ onClose, onSuccess }: Props) {
  const [form, setForm] = useState({
    name: '', phone: '', email: '', courseInterested: 'BTech',
    preferredCountry: '', countryId: '', collegeId: '', courseId: '',
    assignedUserId: '', source: 'MANUAL', notes: '',
  });
  const [incentivePreview, setIncentivePreview] = useState<any>(null);

  const { data: countries } = useQuery({ queryKey: ['countries'], queryFn: () => collegesApi.countries().then((r) => r.data) });
  const { data: colleges } = useQuery({
    queryKey: ['colleges', form.countryId],
    queryFn: () => collegesApi.list({ countryId: form.countryId || undefined }).then((r) => r.data),
    enabled: true,
  });
  const { data: courses } = useQuery({
    queryKey: ['courses', form.collegeId],
    queryFn: () => coursesApi.list({ collegeId: form.collegeId }).then((r) => r.data),
    enabled: !!form.collegeId,
  });
  const { data: agents } = useQuery({ queryKey: ['agents'], queryFn: () => usersApi.salesAgents().then((r) => r.data) });

  const previewMutation = useMutation({
    mutationFn: (courseId: string) => leadsApi.incentivePreview(courseId).then((r) => r.data),
    onSuccess: (data) => setIncentivePreview(data),
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => leadsApi.create(data),
    onSuccess: () => { toast.success('Lead created successfully!'); onSuccess(); },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed to create lead'),
  });

  useEffect(() => {
    if (form.courseId) previewMutation.mutate(form.courseId);
    else setIncentivePreview(null);
  }, [form.courseId]);

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) return toast.error('Name and phone are required');
    createMutation.mutate({
      name: form.name, phone: form.phone,
      email: form.email || undefined, courseInterested: form.courseInterested,
      preferredCountry: form.preferredCountry || undefined,
      countryId: form.countryId || undefined,
      collegeId: form.collegeId || undefined,
      courseId: form.courseId || undefined,
      assignedUserId: form.assignedUserId || undefined,
      source: form.source, notes: form.notes || undefined,
    });
  };

  return (
    <Modal open onClose={onClose} title="Add New Lead" size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Basic info */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Full Name *</label>
            <input className="input" placeholder="Rahul Sharma" value={form.name} onChange={(e) => set('name', e.target.value)} required />
          </div>
          <div>
            <label className="label">Phone *</label>
            <input className="input" placeholder="9876543210" value={form.phone} onChange={(e) => set('phone', e.target.value)} required />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Email</label>
            <input className="input" type="email" placeholder="rahul@example.com" value={form.email} onChange={(e) => set('email', e.target.value)} />
          </div>
          <div>
            <label className="label">Course Interest *</label>
            <select className="input" value={form.courseInterested} onChange={(e) => set('courseInterested', e.target.value)}>
              {['BTech', 'MBA', 'MS', 'ME', 'MCA', 'BCA', 'Other'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        {/* Country + College + Course */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="label">Country</label>
            <select className="input" value={form.countryId} onChange={(e) => { set('countryId', e.target.value); set('collegeId', ''); set('courseId', ''); }}>
              <option value="">Select country</option>
              {countries?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">College</label>
            <select className="input" value={form.collegeId} onChange={(e) => { set('collegeId', e.target.value); set('courseId', ''); }}>
              <option value="">Select college</option>
              {colleges?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Course</label>
            <select className="input" value={form.courseId} onChange={(e) => set('courseId', e.target.value)} disabled={!form.collegeId}>
              <option value="">Select course</option>
              {courses?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        </div>

        {/* Incentive Preview */}
        {incentivePreview && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-3">
            <Calculator className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-sm font-semibold text-green-800">Incentive Auto-Calculated</div>
              <div className="text-sm text-green-700 mt-0.5">
                <span className="font-bold text-lg">{formatCurrency(incentivePreview.incentiveAmount)}</span>
                <span className="ml-2 text-xs text-green-600">({incentivePreview.breakdown})</span>
              </div>
              <div className="text-xs text-green-600 mt-1">
                Source: {incentivePreview.source} · Fees: {formatCurrency(incentivePreview.fees)}
              </div>
            </div>
          </div>
        )}

        {/* Assignment + Source */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Assign To</label>
            <select className="input" value={form.assignedUserId} onChange={(e) => set('assignedUserId', e.target.value)}>
              <option value="">Auto-assign to me</option>
              {agents?.map((a: any) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Source</label>
            <select className="input" value={form.source} onChange={(e) => set('source', e.target.value)}>
              {['MANUAL', 'SULEKHA', 'WEBSITE', 'REFERRAL'].map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="label">Notes</label>
          <textarea className="input h-20 resize-none" placeholder="Initial notes about this lead..."
            value={form.notes} onChange={(e) => set('notes', e.target.value)} />
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          <button type="submit" disabled={createMutation.isPending} className="btn-primary flex items-center gap-2">
            {createMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Create Lead
          </button>
        </div>
      </form>
    </Modal>
  );
}
