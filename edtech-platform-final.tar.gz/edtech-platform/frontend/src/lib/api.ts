import axios from 'axios';
import Cookies from 'js-cookie';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

export const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token on every request
api.interceptors.request.use((config) => {
  const token = Cookies.get('token') || (typeof window !== 'undefined' ? localStorage.getItem('token') : null);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      Cookies.remove('token');
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  },
);

// ─── Auth ──────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  me: () => api.get('/auth/me'),
};

// ─── Leads ─────────────────────────────────────────────
export const leadsApi = {
  list: (params?: Record<string, any>) => api.get('/leads', { params }),
  get: (id: string) => api.get(`/leads/${id}`),
  create: (data: any) => api.post('/leads', data),
  update: (id: string, data: any) => api.put(`/leads/${id}`, data),
  addNote: (id: string, note: string) => api.patch(`/leads/${id}/note`, { note }),
  assign: (id: string, assignedUserId: string) => api.patch(`/leads/${id}/assign`, { assignedUserId }),
  stats: () => api.get('/leads/stats'),
  slaReport: () => api.get('/leads/sla-report'),
  incentiveSummary: (userId?: string) => api.get('/leads/incentive-summary', { params: { userId } }),
  incentivePreview: (courseId: string) => api.post('/leads/incentive-preview', { courseId }),
  activities: (id: string) => api.get(`/leads/${id}/activities`),
  slaStatus: (id: string) => api.get(`/leads/${id}/sla`),
  recalculateIncentives: () => api.post('/leads/recalculate-incentives'),
};

// ─── Colleges ──────────────────────────────────────────
export const collegesApi = {
  list: (params?: Record<string, any>) => api.get('/colleges', { params }),
  get: (id: string) => api.get(`/colleges/${id}`),
  countries: () => api.get('/colleges/countries'),
};

// ─── Courses ───────────────────────────────────────────
export const coursesApi = {
  list: (params?: Record<string, any>) => api.get('/courses', { params }),
  get: (id: string) => api.get(`/courses/${id}`),
  types: () => api.get('/courses/types'),
};

// ─── Users ─────────────────────────────────────────────
export const usersApi = {
  list: (role?: string) => api.get('/users', { params: { role } }),
  salesAgents: () => api.get('/users/sales-agents'),
  create: (data: any) => api.post('/users', data),
  update: (id: string, data: any) => api.put(`/users/${id}`, data),
  deactivate: (id: string) => api.patch(`/users/${id}/deactivate`),
};

// ─── Excel ─────────────────────────────────────────────
export const excelApi = {
  upload: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return api.post('/excel/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  template: () => api.get('/excel/template', { responseType: 'blob' }),
  exportLeads: () => api.get('/excel/export-leads', { responseType: 'blob' }),
};

// ─── Expenses ──────────────────────────────────────────
export const expensesApi = {
  list: (params?: Record<string, any>) => api.get('/expenses', { params }),
  get: (id: string) => api.get(`/expenses/${id}`),
  create: (data: any) => api.post('/expenses', data),
  approve: (id: string) => api.patch(`/expenses/${id}/approve`),
  reject: (id: string) => api.patch(`/expenses/${id}/reject`),
  summary: (year: number) => api.get(`/expenses/summary/${year}`),
};

// ─── Dashboard ─────────────────────────────────────────
export const dashboardApi = {
  admin: () => api.get('/dashboard/admin'),
  sales: () => api.get('/dashboard/sales'),
  funnel: () => api.get('/dashboard/funnel'),
  revenueVsExpense: (year?: number) => api.get('/dashboard/revenue-expense', { params: { year } }),
  config: () => api.get('/dashboard/config'),
  updateConfig: (key: string, value: string) => api.put(`/dashboard/config/${key}`, { value }),
};

// ─── Sulekha ───────────────────────────────────────────
export const sulekhaApi = {
  syncNow: () => api.post('/sulekha/sync'),
  history: () => api.get('/sulekha/history'),
};

// ─── Notifications ─────────────────────────────────────
export const notificationsApi = {
  list: (unreadOnly?: boolean) => api.get('/notifications', { params: { unreadOnly } }),
  unreadCount: () => api.get('/notifications/unread-count'),
  markRead: (id: string) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
};
