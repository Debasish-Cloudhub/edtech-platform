#!/usr/bin/env bash
# ============================================================
# Migrate database from Railway → Hostinger
# Run this AFTER deploy-hostinger.sh is complete
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

echo ""
echo "🔄 Railway → Hostinger Migration"
echo "================================="
echo ""

read -p "Railway DATABASE_URL: " RAILWAY_DB
read -p "Hostinger VPS IP: " VPS_IP
read -p "Hostinger DB password: " HOSTINGER_DB_PASS

BACKUP_FILE="railway_backup_$(date +%Y%m%d_%H%M%S).sql"

# Step 1: Dump from Railway
log "Exporting database from Railway..."
pg_dump "$RAILWAY_DB" \
  --no-owner \
  --no-acl \
  --clean \
  --if-exists \
  > "$BACKUP_FILE"
ok "Database exported: $BACKUP_FILE ($(du -sh $BACKUP_FILE | cut -f1))"

# Step 2: Copy to Hostinger
log "Uploading backup to Hostinger VPS..."
scp "$BACKUP_FILE" "root@${VPS_IP}:/root/edtech-platform/${BACKUP_FILE}"
ok "Backup uploaded"

# Step 3: Import on Hostinger
log "Importing into Hostinger PostgreSQL..."
ssh "root@${VPS_IP}" "
  cd /root/edtech-platform
  docker compose exec -T db psql \
    -U edtech_user \
    -d edtech_db \
    < ${BACKUP_FILE} 2>&1 | tail -5
  rm ${BACKUP_FILE}
"
ok "Database imported"

# Step 4: Verify
log "Verifying migration..."
ssh "root@${VPS_IP}" "
  docker compose exec -T db psql \
    -U edtech_user \
    -d edtech_db \
    -c 'SELECT COUNT(*) as leads FROM leads; SELECT COUNT(*) as users FROM users;'
"

ok "Migration complete! Verify your app is working at your domain."

# Cleanup local backup
rm "$BACKUP_FILE"
log "Local backup cleaned up"
