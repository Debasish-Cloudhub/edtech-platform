#!/usr/bin/env bash
# ============================================================
# EdTech Platform — Local Dev Setup Script
# Run: chmod +x scripts/setup-local.sh && ./scripts/setup-local.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

echo ""
echo "🎓 ============================================="
echo "   EduConsult Platform — Local Setup"
echo "   BTech & MBA Admissions Platform"
echo "==============================================="
echo ""

# ── Prerequisites check ─────────────────────────────────────
log "Checking prerequisites..."

command -v node >/dev/null 2>&1 || fail "Node.js is required. Install from https://nodejs.org"
command -v npm  >/dev/null 2>&1 || fail "npm is required."
command -v psql >/dev/null 2>&1 || warn "psql not found — make sure PostgreSQL is running."

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
  fail "Node.js 18+ required. Current: $(node -v)"
fi
ok "Node.js $(node -v)"

# ── Backend setup ────────────────────────────────────────────
log "Setting up backend..."

cd backend

if [ ! -f .env ]; then
  cp .env.example .env
  ok "Created backend/.env from .env.example"
  warn "⚠️  Please update DATABASE_URL in backend/.env before continuing."
  echo ""
  echo "  Default: postgresql://username:password@localhost:5432/edtech_db"
  echo "  Edit:    nano backend/.env"
  echo ""
  read -p "Press ENTER once you've configured DATABASE_URL..."
fi

log "Installing backend dependencies..."
npm install --silent
ok "Backend dependencies installed"

log "Generating Prisma client..."
npx prisma generate --silent
ok "Prisma client generated"

log "Running database migrations..."
npx prisma migrate deploy 2>&1 | tail -3
ok "Migrations applied"

log "Seeding database with test data..."
npx ts-node prisma/seed.ts
ok "Database seeded"

cd ..

# ── Frontend setup ───────────────────────────────────────────
log "Setting up frontend..."

cd frontend

if [ ! -f .env.local ]; then
  cp .env.local.example .env.local
  ok "Created frontend/.env.local"
fi

log "Installing frontend dependencies..."
npm install --silent
ok "Frontend dependencies installed"

cd ..

# ── Summary ──────────────────────────────────────────────────
echo ""
echo -e "${GREEN}✅ Setup complete!${NC}"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🚀 Start commands:"
echo ""
echo "  Backend:  cd backend && npm run start:dev"
echo "  Frontend: cd frontend && npm run dev"
echo ""
echo "  📍 URLs:"
echo "  App:        http://localhost:3000"
echo "  API:        http://localhost:4000/api/v1"
echo "  Swagger:    http://localhost:4000/api/docs"
echo ""
echo "  🔑 Test Credentials:"
echo "  admin@test.com   / Test@1234  (Admin)"
echo "  sales@test.com   / Test@1234  (Sales Agent)"
echo "  student@test.com / Test@1234  (Student)"
echo "  finance@test.com / Test@1234  (Finance Manager)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
