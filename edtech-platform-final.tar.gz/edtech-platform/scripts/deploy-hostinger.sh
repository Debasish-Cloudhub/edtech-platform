#!/usr/bin/env bash
# ============================================================
# EdTech Platform — Hostinger VPS Deployment Script
# Run on your Hostinger VPS as root:
#   curl -sO https://raw.githubusercontent.com/yourname/edtech-platform/main/scripts/deploy-hostinger.sh
#   chmod +x deploy-hostinger.sh && ./deploy-hostinger.sh
# ============================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

DOMAIN=""
REPO_URL=""
APP_DIR="/root/edtech-platform"

echo ""
echo "🎓 ============================================="
echo "   EduConsult — Hostinger Production Deploy"
echo "==============================================="
echo ""

# Get config
read -p "Enter your domain (e.g. educonsult.in): " DOMAIN
read -p "Enter your GitHub repo URL: " REPO_URL
read -s -p "Enter DB password to use: " DB_PASSWORD
echo ""
read -s -p "Enter JWT secret (min 32 chars): " JWT_SECRET
echo ""

# ── Install Docker ───────────────────────────────────────────
log "Installing Docker..."
if ! command -v docker &>/dev/null; then
  curl -fsSL https://get.docker.com | sh
  systemctl enable docker
  ok "Docker installed"
else
  ok "Docker already installed"
fi

if ! command -v docker compose &>/dev/null; then
  apt-get install -y docker-compose-plugin 2>/dev/null || true
fi
ok "Docker Compose ready"

# ── Install Certbot ──────────────────────────────────────────
log "Installing Certbot for SSL..."
apt-get update -qq
apt-get install -y certbot 2>/dev/null
ok "Certbot installed"

# ── Clone repo ───────────────────────────────────────────────
log "Cloning repository..."
if [ -d "$APP_DIR" ]; then
  cd "$APP_DIR" && git pull origin main
else
  git clone "$REPO_URL" "$APP_DIR"
  cd "$APP_DIR"
fi
ok "Repository ready at $APP_DIR"

# ── Create .env ──────────────────────────────────────────────
log "Creating environment configuration..."
cat > "$APP_DIR/.env" << EOF
NODE_ENV=production
PORT=4000
DATABASE_URL=postgresql://edtech_user:${DB_PASSWORD}@db:5432/edtech_db
DB_PASSWORD=${DB_PASSWORD}
JWT_SECRET=${JWT_SECRET}
JWT_EXPIRES_IN=7d
ALLOWED_ORIGINS=https://student.${DOMAIN},https://sales.${DOMAIN},https://admin.${DOMAIN},https://expenses.${DOMAIN}
NEXT_PUBLIC_API_URL=https://admin.${DOMAIN}/api/v1
EOF
ok ".env created"

# ── SSL Certificates ─────────────────────────────────────────
log "Obtaining SSL certificates..."
log "Make sure DNS A records point to this server before continuing:"
echo ""
echo "  student.${DOMAIN}  →  $(curl -s ifconfig.me)"
echo "  sales.${DOMAIN}    →  $(curl -s ifconfig.me)"
echo "  admin.${DOMAIN}    →  $(curl -s ifconfig.me)"
echo "  expenses.${DOMAIN} →  $(curl -s ifconfig.me)"
echo ""
read -p "Press ENTER once DNS is configured..."

certbot certonly --standalone \
  -d "student.${DOMAIN}" \
  -d "sales.${DOMAIN}" \
  -d "admin.${DOMAIN}" \
  -d "expenses.${DOMAIN}" \
  --agree-tos --non-interactive --email "admin@${DOMAIN}" || warn "SSL cert failed — check DNS records"

# Copy certs
mkdir -p "$APP_DIR/deployment/ssl"
if [ -f "/etc/letsencrypt/live/student.${DOMAIN}/fullchain.pem" ]; then
  cp "/etc/letsencrypt/live/student.${DOMAIN}/fullchain.pem" "$APP_DIR/deployment/ssl/"
  cp "/etc/letsencrypt/live/student.${DOMAIN}/privkey.pem" "$APP_DIR/deployment/ssl/"
  ok "SSL certificates copied"
fi

# Patch nginx.conf domain
sed -i "s/yourdomain\.com/${DOMAIN}/g" "$APP_DIR/deployment/nginx.conf"
ok "Nginx configured for $DOMAIN"

# ── Deploy ───────────────────────────────────────────────────
log "Building and starting containers..."
cd "$APP_DIR"
docker compose --profile production up -d --build

log "Running database migrations..."
sleep 10  # Wait for DB to be ready
docker compose exec -T backend npx prisma migrate deploy
docker compose exec -T backend npx ts-node prisma/seed.ts || true

# ── SSL Auto-renewal ─────────────────────────────────────────
log "Setting up SSL auto-renewal..."
(crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet && docker compose -f ${APP_DIR}/docker-compose.yml restart nginx") | crontab -
ok "SSL renewal cron configured"

# ── Health check ─────────────────────────────────────────────
log "Checking deployment health..."
sleep 5
if curl -fs "https://admin.${DOMAIN}/api/v1/auth/me" -o /dev/null 2>&1; then
  ok "API is responding"
else
  warn "API not responding yet — may still be starting up"
fi

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✅ Deployment Complete!${NC}"
echo ""
echo "  🌐 Portals:"
echo "  Admin:    https://admin.${DOMAIN}"
echo "  Sales:    https://sales.${DOMAIN}"
echo "  Student:  https://student.${DOMAIN}"
echo "  Expenses: https://expenses.${DOMAIN}"
echo "  API Docs: https://admin.${DOMAIN}/api/docs"
echo ""
echo "  🔑 Test Credentials:"
echo "  admin@test.com / Test@1234"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
