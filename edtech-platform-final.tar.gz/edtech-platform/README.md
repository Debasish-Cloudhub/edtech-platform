# 🎓 EduConsult — B2C Education Consulting Platform

Production-ready platform for BTech & MBA admissions consulting in India and abroad.

## Quick Start (Local Dev)

```bash
# 1. Clone and install
git clone https://github.com/yourname/edtech-platform.git
cd edtech-platform

# 2. Setup backend
cd backend
cp .env.example .env
# Edit .env — set DATABASE_URL to your local PostgreSQL

npm install
npx prisma migrate dev --name init
npx prisma generate
npx ts-node prisma/seed.ts   # Seeds test data
npm run start:dev            # Runs on :4000

# 3. Setup frontend (new terminal)
cd ../frontend
npm install
# Create .env.local:
echo "NEXT_PUBLIC_API_URL=http://localhost:4000/api/v1" > .env.local
npm run dev                  # Runs on :3000
```

## Access

| Portal | URL | Credentials |
|--------|-----|-------------|
| App | http://localhost:3000 | — |
| API Docs | http://localhost:4000/api/docs | — |
| Admin | Login with admin@test.com | Test@1234 |
| Sales | Login with sales@test.com | Test@1234 |

## Structure

```
edtech-platform/
├── backend/              # NestJS API
│   ├── src/
│   │   ├── auth/         # JWT auth
│   │   ├── leads/        # CRM + incentive engine + SLA
│   │   ├── colleges/     # College data
│   │   ├── courses/      # Course data
│   │   ├── excel/        # Upload + export
│   │   ├── expenses/     # Expense management
│   │   ├── dashboard/    # Analytics
│   │   ├── sulekha/      # Lead sync cron
│   │   └── notifications/
│   └── prisma/           # DB schema + seed
├── frontend/             # Next.js app
│   └── src/app/
│       ├── dashboard/    # Admin + sales dashboards
│       ├── leads/        # CRM pages
│       ├── colleges/     # Browse colleges
│       ├── courses/      # Browse courses
│       ├── expenses/     # Expense management
│       ├── analytics/    # Charts & reports
│       ├── users/        # User management
│       └── settings/     # Excel upload, config
├── deployment/           # Nginx config
├── docs/                 # Full documentation
├── docker-compose.yml    # Full stack deployment
└── railway.toml          # Railway config
```

## Key Features

- ✅ **Lead CRM** with full lifecycle (Initiated → In Progress → Won/Lost)
- ✅ **Incentive Engine** — auto-calculated from Excel data (% or fixed)
- ✅ **SLA Tracking** — daily cron, breach alerts, admin summary
- ✅ **Sulekha Sync** — daily cron with dedup and retry logic
- ✅ **Excel Upload** — parse → validate → upsert → recalculate incentives
- ✅ **RBAC** — 6 roles with fine-grained permissions
- ✅ **Expense Management** — log → approve/reject → monthly reports
- ✅ **Analytics** — revenue vs expense, funnel, incentive payouts
- ✅ **Notifications** — SLA breach alerts, daily admin summaries
- ✅ **Docker** — one command deployment
- ✅ **Railway + Hostinger** — environment-based, no lock-in

See [docs/DOCUMENTATION.md](docs/DOCUMENTATION.md) for full API reference and deployment guide.
