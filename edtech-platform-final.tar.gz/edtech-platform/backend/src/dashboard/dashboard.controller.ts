import { Controller, Get, Put, Param, Body, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { DashboardService } from './dashboard.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

class UpdateConfigDto {
  @ApiProperty() @IsString() value: string;
}

@ApiTags('Dashboard')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('dashboard')
export class DashboardController {
  constructor(private dashboardService: DashboardService) {}

  @Get('admin')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Admin overview dashboard' })
  getAdminOverview() {
    return this.dashboardService.getAdminOverview();
  }

  @Get('sales')
  @Roles(Role.SALES_AGENT, Role.COUNSELOR, Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Sales agent dashboard' })
  getSalesDashboard(@CurrentUser('sub') userId: string) {
    return this.dashboardService.getSalesAgentDashboard(userId);
  }

  @Get('funnel')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Lead conversion funnel' })
  getFunnel() {
    return this.dashboardService.getLeadFunnel();
  }

  @Get('revenue-expense')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER)
  @ApiOperation({ summary: 'Revenue vs Expense by month' })
  getRevenueVsExpense(@Query('year') year?: string) {
    return this.dashboardService.getRevenueVsExpense(year ? Number(year) : new Date().getFullYear());
  }

  @Get('config')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get system configuration' })
  getConfig() {
    return this.dashboardService.getSystemConfig();
  }

  @Put('config/:key')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Update system config (e.g. DEFAULT_INCENTIVE_PERCENT)' })
  updateConfig(@Param('key') key: string, @Body() dto: UpdateConfigDto) {
    return this.dashboardService.updateSystemConfig(key, dto.value);
  }
}
