import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';
import { LeadStage, Role } from '@prisma/client';

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async getAdminOverview() {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

    const [
      totalLeads,
      leadsThisMonth,
      leadsLastMonth,
      byStage,
      wonLeads,
      slaBreaches,
      totalUsers,
      pendingExpenses,
      approvedExpensesThisMonth,
      recentLeads,
      topSalesAgents,
    ] = await Promise.all([
      // Total leads
      this.prisma.lead.count({ where: { isActive: true } }),

      // This month
      this.prisma.lead.count({
        where: { isActive: true, createdAt: { gte: startOfMonth } },
      }),

      // Last month
      this.prisma.lead.count({
        where: {
          isActive: true,
          createdAt: { gte: startOfLastMonth, lte: endOfLastMonth },
        },
      }),

      // By stage
      this.prisma.lead.groupBy({
        by: ['stage'],
        where: { isActive: true },
        _count: true,
      }),

      // Won leads with incentives
      this.prisma.lead.findMany({
        where: { stage: LeadStage.WON, isActive: true },
        select: { feesAtClosure: true, incentiveAmount: true, createdAt: true },
      }),

      // SLA breaches
      this.prisma.lead.count({
        where: { slaBreach: true, isActive: true, stage: { in: [LeadStage.INITIATED, LeadStage.IN_PROGRESS] } },
      }),

      // Active users
      this.prisma.user.count({ where: { isActive: true } }),

      // Pending expenses
      this.prisma.expense.count({ where: { status: 'PENDING' } }),

      // Approved expenses this month
      this.prisma.expense.aggregate({
        where: { status: 'APPROVED', createdAt: { gte: startOfMonth } },
        _sum: { amount: true },
      }),

      // Recent leads
      this.prisma.lead.findMany({
        where: { isActive: true },
        take: 5,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, name: true, phone: true, stage: true, courseInterested: true,
          assignedUser: { select: { name: true } },
          createdAt: true,
        },
      }),

      // Top sales agents by won leads
      this.prisma.lead.groupBy({
        by: ['assignedUserId'],
        where: { stage: LeadStage.WON, isActive: true, assignedUserId: { not: null } },
        _count: true,
        _sum: { incentiveAmount: true },
        orderBy: { _count: { assignedUserId: 'desc' } },
        take: 5,
      }),
    ]);

    // Enrich top agents with user data
    const topAgentIds = topSalesAgents.map((a) => a.assignedUserId!).filter(Boolean);
    const agentUsers = await this.prisma.user.findMany({
      where: { id: { in: topAgentIds } },
      select: { id: true, name: true, email: true },
    });
    const agentMap = Object.fromEntries(agentUsers.map((u) => [u.id, u]));

    const totalRevenue = wonLeads.reduce((sum, l) => sum + Number(l.feesAtClosure || 0), 0);
    const totalIncentives = wonLeads.reduce((sum, l) => sum + Number(l.incentiveAmount || 0), 0);
    const wonThisMonth = wonLeads.filter((l) => l.createdAt >= startOfMonth).length;
    const conversionRate = totalLeads > 0 ? ((wonLeads.length / totalLeads) * 100).toFixed(1) : '0';

    const stageMap = byStage.reduce(
      (acc, s) => ({ ...acc, [s.stage]: s._count }),
      {} as Record<string, number>,
    );

    return {
      overview: {
        totalLeads,
        leadsThisMonth,
        leadsLastMonth,
        leadGrowth: leadsLastMonth > 0 ? (((leadsThisMonth - leadsLastMonth) / leadsLastMonth) * 100).toFixed(1) : '0',
        wonTotal: wonLeads.length,
        wonThisMonth,
        conversionRate: `${conversionRate}%`,
        slaBreaches,
        totalRevenue,
        totalIncentives,
        totalUsers,
        pendingExpenses,
        approvedExpensesThisMonth: Number(approvedExpensesThisMonth._sum.amount || 0),
      },
      leadsByStage: stageMap,
      recentLeads,
      topSalesAgents: topSalesAgents.map((a) => ({
        user: agentMap[a.assignedUserId!] || { id: a.assignedUserId, name: 'Unknown' },
        wonCount: a._count,
        totalIncentive: Number(a._sum.incentiveAmount || 0),
      })),
    };
  }

  async getSalesAgentDashboard(userId: string) {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [totalLeads, byStage, wonLeads, breachedLeads, myExpenses, recentActivity] =
      await Promise.all([
        this.prisma.lead.count({ where: { assignedUserId: userId, isActive: true } }),
        this.prisma.lead.groupBy({
          by: ['stage'],
          where: { assignedUserId: userId, isActive: true },
          _count: true,
        }),
        this.prisma.lead.findMany({
          where: { assignedUserId: userId, stage: LeadStage.WON, isActive: true },
          select: { incentiveAmount: true, feesAtClosure: true },
        }),
        this.prisma.lead.findMany({
          where: { assignedUserId: userId, slaBreach: true, isActive: true },
          select: { id: true, name: true, phone: true, stage: true, stageStartDate: true },
          take: 10,
        }),
        this.prisma.expense.aggregate({
          where: { userId, createdAt: { gte: startOfMonth } },
          _sum: { amount: true },
          _count: true,
        }),
        this.prisma.leadActivity.findMany({
          where: { userId },
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: { lead: { select: { id: true, name: true } } },
        }),
      ]);

    const totalIncentive = wonLeads.reduce((sum, l) => sum + Number(l.incentiveAmount || 0), 0);
    const totalRevenue = wonLeads.reduce((sum, l) => sum + Number(l.feesAtClosure || 0), 0);
    const stageMap = byStage.reduce((acc, s) => ({ ...acc, [s.stage]: s._count }), {} as Record<string, number>);

    return {
      overview: {
        totalLeads,
        wonLeads: wonLeads.length,
        totalIncentive,
        totalRevenue,
        slaBreaches: breachedLeads.length,
        conversionRate: totalLeads > 0 ? (((wonLeads.length / totalLeads) * 100)).toFixed(1) + '%' : '0%',
        expensesThisMonth: Number(myExpenses._sum.amount || 0),
        expenseCount: myExpenses._count,
      },
      leadsByStage: stageMap,
      breachedLeads,
      recentActivity,
    };
  }

  async getLeadFunnel() {
    const stages = [LeadStage.INITIATED, LeadStage.IN_PROGRESS, LeadStage.WON, LeadStage.LOST];
    const counts = await this.prisma.lead.groupBy({
      by: ['stage'],
      where: { isActive: true },
      _count: true,
    });
    const map = Object.fromEntries(counts.map((c) => [c.stage, c._count]));
    return stages.map((stage) => ({ stage, count: map[stage] || 0 }));
  }

  async getRevenueVsExpense(year: number) {
    const months = Array.from({ length: 12 }, (_, i) => i + 1);

    const [wonLeads, expenses] = await Promise.all([
      this.prisma.lead.findMany({
        where: { stage: LeadStage.WON, isActive: true },
        select: { feesAtClosure: true, incentiveAmount: true, updatedAt: true },
      }),
      this.prisma.expense.findMany({
        where: { year, status: 'APPROVED' },
        select: { month: true, amount: true },
      }),
    ]);

    return months.map((month) => {
      const monthRevenue = wonLeads
        .filter((l) => {
          const d = new Date(l.updatedAt);
          return d.getFullYear() === year && d.getMonth() + 1 === month;
        })
        .reduce((sum, l) => sum + Number(l.feesAtClosure || 0), 0);

      const monthIncentive = wonLeads
        .filter((l) => {
          const d = new Date(l.updatedAt);
          return d.getFullYear() === year && d.getMonth() + 1 === month;
        })
        .reduce((sum, l) => sum + Number(l.incentiveAmount || 0), 0);

      const monthExpense = expenses
        .filter((e) => e.month === month)
        .reduce((sum, e) => sum + Number(e.amount), 0);

      return { month, revenue: monthRevenue, incentives: monthIncentive, expenses: monthExpense };
    });
  }

  async getSystemConfig() {
    const configs = await this.prisma.systemConfig.findMany();
    return Object.fromEntries(configs.map((c) => [c.key, c.value]));
  }

  async updateSystemConfig(key: string, value: string) {
    return this.prisma.systemConfig.upsert({
      where: { key },
      update: { value },
      create: { key, value },
    });
  }
}
