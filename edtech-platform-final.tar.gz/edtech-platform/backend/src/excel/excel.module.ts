import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { ExcelController } from './excel.controller';
import { ExcelService } from './excel.service';
import { CollegesModule } from '../colleges/colleges.module';
import { CoursesModule } from '../courses/courses.module';
import { LeadsModule } from '../leads/leads.module';

@Module({
  imports: [
    MulterModule.register({ dest: '/tmp/uploads' }),
    CollegesModule,
    CoursesModule,
    LeadsModule,
  ],
  controllers: [ExcelController],
  providers: [ExcelService],
  exports: [ExcelService],
})
export class ExcelModule {}
