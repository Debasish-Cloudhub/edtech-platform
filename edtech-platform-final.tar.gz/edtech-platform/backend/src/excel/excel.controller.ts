import {
  Controller, Post, Get, UseGuards, UseInterceptors,
  UploadedFile, Res, HttpCode,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { Response } from 'express';
import { Role } from '@prisma/client';
import { ExcelService } from './excel.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@ApiTags('Excel')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('excel')
export class ExcelController {
  constructor(private excelService: ExcelService) {}

  @Post('upload')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @HttpCode(200)
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Upload college/course Excel file (Admin only)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: { file: { type: 'string', format: 'binary' } },
    },
  })
  async uploadExcel(@UploadedFile() file: Express.Multer.File) {
    if (!file) throw new Error('No file uploaded');
    if (!file.mimetype.includes('spreadsheet') && !file.mimetype.includes('excel') && !file.originalname.endsWith('.xlsx')) {
      throw new Error('Only .xlsx files are supported');
    }
    const result = await this.excelService.processUpload(file.buffer);
    return {
      success: true,
      message: `Import complete: ${result.imported} rows imported, ${result.skipped} skipped`,
      ...result,
    };
  }

  @Get('template')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Download sample Excel template' })
  async downloadTemplate(@Res() res: Response) {
    const buffer = await this.excelService.generateTemplate();
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': 'attachment; filename="edtech-college-course-template.xlsx"',
    });
    res.send(buffer);
  }

  @Get('export-leads')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Export leads to Excel' })
  async exportLeads(@Res() res: Response, @CurrentUser() user: any) {
    const buffer = await this.excelService.exportLeads(user.id, user.role);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="leads-export-${Date.now()}.xlsx"`,
    });
    res.send(buffer);
  }
}
