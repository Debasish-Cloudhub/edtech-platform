import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import * as ExcelJS from 'exceljs';
import { PrismaService } from '../common/prisma/prisma.service';
import { CollegesService } from '../colleges/colleges.service';
import { CoursesService } from '../courses/courses.service';
import { IncentiveService } from '../leads/incentive.service';

export interface ExcelRow {
  collegeName: string;
  country: string;
  city?: string;
  courseName: string;
  courseType: string;
  duration?: string;
  fees: number;
  currency?: string;
  incentivePercent?: number;
  incentiveAmount?: number;
}

export interface ImportResult {
  total: number;
  imported: number;
  skipped: number;
  errors: string[];
  colleges: number;
  courses: number;
}

@Injectable()
export class ExcelService {
  private readonly logger = new Logger(ExcelService.name);

  constructor(
    private prisma: PrismaService,
    private collegesService: CollegesService,
    private coursesService: CoursesService,
    private incentiveService: IncentiveService,
  ) {}

  /**
   * EXPECTED EXCEL FORMAT:
   * Column A: College Name        (required)
   * Column B: Country             (required)
   * Column C: City                (optional)
   * Column D: Course Name         (required)
   * Column E: Course Type         (required: BTech/MBA/MS/etc.)
   * Column F: Duration            (optional: "4 years", "2 years")
   * Column G: Fees                (required: numeric)
   * Column H: Currency            (optional: INR/USD/GBP, default INR)
   * Column I: Incentive %         (optional: e.g. 5 for 5%)
   * Column J: Incentive Amount    (optional: fixed override in same currency)
   *
   * If both Incentive% and Incentive Amount are present, Amount takes priority.
   * Row 1 is always treated as header.
   */
  async parseExcelFile(buffer: Buffer): Promise<ExcelRow[]> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    const worksheet = workbook.worksheets[0];
    if (!worksheet) {
      throw new BadRequestException('Excel file has no worksheets');
    }

    const rows: ExcelRow[] = [];
    const errors: string[] = [];

    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const values = row.values as any[];
      // ExcelJS uses 1-based index, values[0] is undefined
      const collegeName = String(values[1] || '').trim();
      const country = String(values[2] || '').trim();
      const city = values[3] ? String(values[3]).trim() : undefined;
      const courseName = String(values[4] || '').trim();
      const courseType = String(values[5] || '').trim();
      const duration = values[6] ? String(values[6]).trim() : undefined;
      const feesRaw = values[7];
      const currency = values[8] ? String(values[8]).trim() : 'INR';
      const incentivePercentRaw = values[9];
      const incentiveAmountRaw = values[10];

      // Validation
      if (!collegeName || !country || !courseName || !courseType) {
        errors.push(`Row ${rowNumber}: Missing required fields (College, Country, Course Name, Course Type)`);
        return;
      }

      const fees = parseFloat(String(feesRaw));
      if (isNaN(fees) || fees <= 0) {
        errors.push(`Row ${rowNumber}: Invalid fees value "${feesRaw}"`);
        return;
      }

      const incentivePercent = incentivePercentRaw
        ? parseFloat(String(incentivePercentRaw))
        : undefined;
      const incentiveAmount = incentiveAmountRaw
        ? parseFloat(String(incentiveAmountRaw))
        : undefined;

      rows.push({
        collegeName,
        country,
        city,
        courseName,
        courseType,
        duration,
        fees,
        currency,
        incentivePercent: incentivePercent && !isNaN(incentivePercent) ? incentivePercent : undefined,
        incentiveAmount: incentiveAmount && !isNaN(incentiveAmount) ? incentiveAmount : undefined,
      });
    });

    if (errors.length > 0 && rows.length === 0) {
      throw new BadRequestException(`Excel parsing failed:\n${errors.join('\n')}`);
    }

    return rows;
  }

  /**
   * Import parsed rows into DB - upsert colleges and courses
   */
  async importRows(rows: ExcelRow[]): Promise<ImportResult> {
    const result: ImportResult = {
      total: rows.length,
      imported: 0,
      skipped: 0,
      errors: [],
      colleges: 0,
      courses: 0,
    };

    const collegeTracker = new Set<string>();

    for (const row of rows) {
      try {
        // Upsert college
        const collegeKey = `${row.collegeName}::${row.country}`;
        if (!collegeTracker.has(collegeKey)) {
          await this.collegesService.upsertCollege({
            name: row.collegeName,
            countryName: row.country,
            city: row.city,
          });
          collegeTracker.add(collegeKey);
          result.colleges++;
        }

        // Upsert course
        await this.coursesService.upsertCourse({
          collegeName: row.collegeName,
          countryName: row.country,
          courseName: row.courseName,
          courseType: row.courseType,
          duration: row.duration,
          fees: row.fees,
          currency: row.currency,
          incentivePercent: row.incentivePercent,
          incentiveAmount: row.incentiveAmount,
        });

        result.courses++;
        result.imported++;
      } catch (err) {
        result.skipped++;
        result.errors.push(`${row.collegeName} / ${row.courseName}: ${err.message}`);
        this.logger.warn(`Import error: ${err.message}`);
      }
    }

    // After import, recalculate incentives for all active leads
    if (result.imported > 0) {
      const recalc = await this.incentiveService.recalculateAllLeads();
      this.logger.log(`Recalculated incentives for ${recalc.updated} leads`);
    }

    return result;
  }

  /**
   * Full pipeline: parse buffer → validate → import to DB
   */
  async processUpload(buffer: Buffer): Promise<ImportResult & { parseErrors: string[] }> {
    let rows: ExcelRow[] = [];
    const parseErrors: string[] = [];

    try {
      rows = await this.parseExcelFile(buffer);
    } catch (err) {
      if (err instanceof BadRequestException) {
        throw err;
      }
      throw new BadRequestException(`Failed to parse Excel: ${err.message}`);
    }

    const importResult = await this.importRows(rows);
    return { ...importResult, parseErrors };
  }

  /**
   * Generate a sample Excel template for download
   */
  async generateTemplate(): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('College & Course Data');

    // Header row
    sheet.columns = [
      { header: 'College Name *', key: 'collegeName', width: 30 },
      { header: 'Country *', key: 'country', width: 15 },
      { header: 'City', key: 'city', width: 20 },
      { header: 'Course Name *', key: 'courseName', width: 35 },
      { header: 'Course Type *', key: 'courseType', width: 15 },
      { header: 'Duration', key: 'duration', width: 15 },
      { header: 'Fees (Number) *', key: 'fees', width: 18 },
      { header: 'Currency', key: 'currency', width: 12 },
      { header: 'Incentive %', key: 'incentivePercent', width: 14 },
      { header: 'Incentive Amount', key: 'incentiveAmount', width: 18 },
    ];

    // Style header
    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF2563EB' },
    };

    // Sample data
    const samples = [
      ['IIT Delhi', 'India', 'New Delhi', 'B.Tech Computer Science', 'BTech', '4 years', 800000, 'INR', 5, ''],
      ['IIM Ahmedabad', 'India', 'Ahmedabad', 'MBA General Management', 'MBA', '2 years', 2500000, 'INR', 4, ''],
      ['MIT', 'USA', 'Cambridge, MA', 'MS Computer Science', 'MS', '2 years', 4500000, 'INR', 6, ''],
      ['Stanford University', 'USA', 'Stanford, CA', 'MBA', 'MBA', '2 years', '', 'INR', '', 300000],
      ['University of Toronto', 'Canada', 'Toronto', 'M.Eng Computer Engineering', 'ME', '1.5 years', 2200000, 'INR', 5, ''],
    ];

    samples.forEach((row) => sheet.addRow(row));

    // Add notes sheet
    const notesSheet = workbook.addWorksheet('Instructions');
    notesSheet.addRows([
      ['FIELD', 'REQUIRED', 'DESCRIPTION'],
      ['College Name', 'YES', 'Full name of college/university'],
      ['Country', 'YES', 'Country name (e.g. India, USA, UK, Canada, Germany)'],
      ['City', 'NO', 'City where college is located'],
      ['Course Name', 'YES', 'Full name of the course/program'],
      ['Course Type', 'YES', 'BTech / MBA / MS / ME / MCA / BCA / Other'],
      ['Duration', 'NO', 'e.g. 4 years, 2 years, 18 months'],
      ['Fees (Number)', 'YES', 'Total program fee as a number (no commas or symbols)'],
      ['Currency', 'NO', 'INR / USD / GBP / CAD / EUR (default: INR)'],
      ['Incentive %', 'NO', 'Incentive percentage e.g. 5 means 5% of fees'],
      ['Incentive Amount', 'NO', 'Fixed incentive amount (overrides Incentive % if both provided)'],
      ['', '', ''],
      ['NOTES', '', ''],
      ['1. If both Incentive% and Incentive Amount are filled, Amount takes priority.'],
      ['2. If neither is filled, the system default % from Admin config is used.'],
      ['3. Row 1 is always the header - do not delete it.'],
      ['4. Uploading overwrites existing data for matching College+Course combinations.'],
      ['5. After upload, incentives for all active leads will be auto-recalculated.'],
    ]);

    notesSheet.getRow(1).font = { bold: true };
    notesSheet.columns = [{ width: 20 }, { width: 12 }, { width: 70 }];

    const arrayBuffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(arrayBuffer);
  }

  /**
   * Export leads to Excel
   */
  async exportLeads(userId?: string, role?: string): Promise<Buffer> {
    const where: any = { isActive: true };
    if (role === 'SALES_AGENT' || role === 'COUNSELOR') {
      where.assignedUserId = userId;
    }

    const leads = await this.prisma.lead.findMany({
      where,
      include: {
        college: { select: { name: true } },
        course: { select: { name: true, fees: true } },
        country: { select: { name: true } },
        assignedUser: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Leads Export');

    sheet.columns = [
      { header: 'Name', key: 'name', width: 20 },
      { header: 'Phone', key: 'phone', width: 15 },
      { header: 'Email', key: 'email', width: 25 },
      { header: 'Course Interest', key: 'courseInterested', width: 15 },
      { header: 'Country', key: 'country', width: 15 },
      { header: 'College', key: 'college', width: 30 },
      { header: 'Course', key: 'course', width: 35 },
      { header: 'Stage', key: 'stage', width: 15 },
      { header: 'Source', key: 'source', width: 12 },
      { header: 'Assigned To', key: 'assignedUser', width: 20 },
      { header: 'Fees at Closure', key: 'feesAtClosure', width: 18 },
      { header: 'Incentive Amount', key: 'incentiveAmount', width: 18 },
      { header: 'Incentive Source', key: 'incentiveSource', width: 16 },
      { header: 'SLA Breach', key: 'slaBreach', width: 12 },
      { header: 'Stage Start', key: 'stageStartDate', width: 18 },
      { header: 'Created At', key: 'createdAt', width: 18 },
    ];

    sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    sheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF1E3A5F' },
    };

    leads.forEach((lead) => {
      sheet.addRow({
        name: lead.name,
        phone: lead.phone,
        email: lead.email || '',
        courseInterested: lead.courseInterested,
        country: lead.country?.name || lead.preferredCountry || '',
        college: lead.college?.name || '',
        course: lead.course?.name || '',
        stage: lead.stage,
        source: lead.source,
        assignedUser: lead.assignedUser?.name || 'Unassigned',
        feesAtClosure: lead.feesAtClosure ? Number(lead.feesAtClosure) : '',
        incentiveAmount: lead.incentiveAmount ? Number(lead.incentiveAmount) : '',
        incentiveSource: lead.incentiveSource || '',
        slaBreach: lead.slaBreach ? 'YES' : 'No',
        stageStartDate: lead.stageStartDate.toLocaleDateString('en-IN'),
        createdAt: lead.createdAt.toLocaleDateString('en-IN'),
      });
    });

    const arrayBuffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(arrayBuffer);
  }
}
