import { IsString, IsNumber, IsPositive, IsOptional, IsInt, Min, Max } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateExpenseDto {
  @ApiProperty({ example: 'Travel' }) @IsString() category: string;
  @ApiProperty({ example: 1500 }) @IsNumber() @IsPositive() @Type(() => Number) amount: number;
  @ApiPropertyOptional({ example: 'INR' }) @IsOptional() @IsString() currency?: string;
  @ApiProperty({ example: 'Flight to Mumbai for client meeting' }) @IsString() description: string;
  @ApiPropertyOptional() @IsOptional() @IsInt() @Min(1) @Max(12) @Type(() => Number) month?: number;
  @ApiPropertyOptional() @IsOptional() @IsInt() @Type(() => Number) year?: number;
}
