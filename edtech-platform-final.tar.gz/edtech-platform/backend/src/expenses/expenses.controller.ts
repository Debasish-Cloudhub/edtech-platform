// expenses.controller.ts
import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { ExpenseStatus, Role } from '@prisma/client';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@ApiTags('Expenses')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('expenses')
export class ExpensesController {
  constructor(private expensesService: ExpensesService) {}

  @Get()
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'List expenses' })
  @ApiQuery({ name: 'month', required: false, type: Number })
  @ApiQuery({ name: 'year', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false, enum: ExpenseStatus })
  @ApiQuery({ name: 'userId', required: false })
  findAll(
    @CurrentUser() user: any,
    @Query('month') month?: string,
    @Query('year') year?: string,
    @Query('status') status?: ExpenseStatus,
    @Query('userId') userId?: string,
  ) {
    return this.expensesService.findAll(user, {
      month: month ? Number(month) : undefined,
      year: year ? Number(year) : undefined,
      status,
      userId,
    });
  }

  @Get('summary/:year')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER)
  @ApiOperation({ summary: 'Get monthly expense summary for a year' })
  getMonthlySummary(@Param('year') year: string) {
    return this.expensesService.getMonthlySummary(Number(year));
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Get expense by ID' })
  findOne(@Param('id') id: string, @CurrentUser() user: any) {
    return this.expensesService.findOne(id, user);
  }

  @Post()
  @Roles(Role.SALES_AGENT, Role.COUNSELOR, Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Log a new expense' })
  create(@Body() dto: CreateExpenseDto, @CurrentUser('sub') userId: string) {
    return this.expensesService.create(dto, userId);
  }

  @Patch(':id/approve')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER)
  @ApiOperation({ summary: 'Approve an expense' })
  approve(@Param('id') id: string, @CurrentUser('sub') adminId: string) {
    return this.expensesService.approve(id, adminId);
  }

  @Patch(':id/reject')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.FINANCE_MANAGER)
  @ApiOperation({ summary: 'Reject an expense' })
  reject(@Param('id') id: string, @CurrentUser('sub') adminId: string) {
    return this.expensesService.reject(id, adminId);
  }
}
