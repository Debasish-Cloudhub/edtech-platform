import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';
import { ExpenseStatus, Role } from '@prisma/client';
import { CreateExpenseDto } from './dto/create-expense.dto';

@Injectable()
export class ExpensesService {
  constructor(private prisma: PrismaService) {}

  async findAll(user: any, filters?: { month?: number; year?: number; status?: ExpenseStatus; userId?: string }) {
    const where: any = {};

    // Sales agents see only their own expenses
    if (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) {
      where.userId = user.id;
    } else if (filters?.userId) {
      where.userId = filters.userId;
    }

    if (filters?.month) where.month = filters.month;
    if (filters?.year) where.year = filters.year;
    if (filters?.status) where.status = filters.status;

    const [expenses, total] = await Promise.all([
      this.prisma.expense.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, email: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.expense.count({ where }),
    ]);

    const totalAmount = expenses.reduce((sum, e) => sum + Number(e.amount), 0);

    return { data: expenses, total, totalAmount };
  }

  async findOne(id: string, user: any) {
    const expense = await this.prisma.expense.findUnique({
      where: { id },
      include: { user: { select: { id: true, name: true } } },
    });
    if (!expense) throw new NotFoundException('Expense not found');
    if (
      (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) &&
      expense.userId !== user.id
    ) {
      throw new ForbiddenException('Access denied');
    }
    return expense;
  }

  async create(dto: CreateExpenseDto, userId: string) {
    const now = new Date();
    return this.prisma.expense.create({
      data: {
        userId,
        category: dto.category,
        amount: dto.amount,
        currency: dto.currency || 'INR',
        description: dto.description,
        month: dto.month || now.getMonth() + 1,
        year: dto.year || now.getFullYear(),
        status: ExpenseStatus.PENDING,
      },
    });
  }

  async approve(id: string, adminId: string) {
    const expense = await this.prisma.expense.findUnique({ where: { id } });
    if (!expense) throw new NotFoundException('Expense not found');
    return this.prisma.expense.update({
      where: { id },
      data: { status: ExpenseStatus.APPROVED, approvedBy: adminId, approvedAt: new Date() },
    });
  }

  async reject(id: string, adminId: string) {
    const expense = await this.prisma.expense.findUnique({ where: { id } });
    if (!expense) throw new NotFoundException('Expense not found');
    return this.prisma.expense.update({
      where: { id },
      data: { status: ExpenseStatus.REJECTED, approvedBy: adminId, approvedAt: new Date() },
    });
  }

  async getMonthlySummary(year: number) {
    const expenses = await this.prisma.expense.findMany({
      where: { year, status: ExpenseStatus.APPROVED },
      select: { month: true, amount: true, category: true, userId: true },
    });

    const byMonth: Record<number, { total: number; count: number; byCategory: Record<string, number> }> = {};

    for (let m = 1; m <= 12; m++) {
      byMonth[m] = { total: 0, count: 0, byCategory: {} };
    }

    for (const e of expenses) {
      byMonth[e.month].total += Number(e.amount);
      byMonth[e.month].count++;
      byMonth[e.month].byCategory[e.category] =
        (byMonth[e.month].byCategory[e.category] || 0) + Number(e.amount);
    }

    const totalYear = expenses.reduce((sum, e) => sum + Number(e.amount), 0);

    return { year, totalYear, byMonth };
  }
}
