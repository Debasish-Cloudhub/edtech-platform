import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';

@Injectable()
export class CoursesService {
  constructor(private prisma: PrismaService) {}

  async findAll(filters?: {
    collegeId?: string;
    courseType?: string;
    countryId?: string;
    search?: string;
    minFees?: number;
    maxFees?: number;
  }) {
    const where: any = { isActive: true };

    if (filters?.collegeId) where.collegeId = filters.collegeId;
    if (filters?.courseType) where.courseType = filters.courseType;
    if (filters?.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { college: { name: { contains: filters.search, mode: 'insensitive' } } },
      ];
    }
    if (filters?.countryId) {
      where.college = { countryId: filters.countryId };
    }
    if (filters?.minFees || filters?.maxFees) {
      where.fees = {};
      if (filters.minFees) where.fees.gte = filters.minFees;
      if (filters.maxFees) where.fees.lte = filters.maxFees;
    }

    return this.prisma.course.findMany({
      where,
      include: {
        college: {
          include: { country: { select: { id: true, name: true, code: true } } },
        },
      },
      orderBy: [{ college: { name: 'asc' } }, { name: 'asc' }],
    });
  }

  async findOne(id: string) {
    const course = await this.prisma.course.findUnique({
      where: { id },
      include: {
        college: { include: { country: true } },
      },
    });
    if (!course) throw new NotFoundException('Course not found');
    return course;
  }

  async getCourseTypes() {
    const types = await this.prisma.course.groupBy({
      by: ['courseType'],
      where: { isActive: true },
      _count: true,
    });
    return types.map((t) => ({ courseType: t.courseType, count: t._count }));
  }

  async upsertCourse(data: {
    collegeName: string;
    countryName: string;
    courseName: string;
    courseType: string;
    duration?: string;
    fees: number;
    currency?: string;
    incentivePercent?: number;
    incentiveAmount?: number;
  }) {
    // Find college by name + country
    const college = await this.prisma.college.findFirst({
      where: {
        name: data.collegeName,
        country: { name: data.countryName },
      },
    });

    if (!college) {
      throw new NotFoundException(`College "${data.collegeName}" in "${data.countryName}" not found`);
    }

    const existing = await this.prisma.course.findFirst({
      where: { collegeId: college.id, name: data.courseName },
    });

    const courseData = {
      name: data.courseName,
      collegeId: college.id,
      courseType: data.courseType,
      duration: data.duration,
      fees: data.fees,
      currency: data.currency || 'INR',
      incentivePercent: data.incentivePercent,
      incentiveAmount: data.incentiveAmount,
      isActive: true,
    };

    if (existing) {
      return this.prisma.course.update({ where: { id: existing.id }, data: courseData });
    }
    return this.prisma.course.create({ data: courseData });
  }
}
