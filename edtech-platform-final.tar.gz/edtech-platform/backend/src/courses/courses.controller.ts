import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { CoursesService } from './courses.service';

@ApiTags('Courses')
@Controller('courses')
export class CoursesController {
  constructor(private coursesService: CoursesService) {}

  @Get()
  @ApiOperation({ summary: 'List all courses (public - student portal)' })
  @ApiQuery({ name: 'collegeId', required: false })
  @ApiQuery({ name: 'courseType', required: false })
  @ApiQuery({ name: 'countryId', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'minFees', required: false, type: Number })
  @ApiQuery({ name: 'maxFees', required: false, type: Number })
  findAll(
    @Query('collegeId') collegeId?: string,
    @Query('courseType') courseType?: string,
    @Query('countryId') countryId?: string,
    @Query('search') search?: string,
    @Query('minFees') minFees?: string,
    @Query('maxFees') maxFees?: string,
  ) {
    return this.coursesService.findAll({
      collegeId,
      courseType,
      countryId,
      search,
      minFees: minFees ? Number(minFees) : undefined,
      maxFees: maxFees ? Number(maxFees) : undefined,
    });
  }

  @Get('types')
  @ApiOperation({ summary: 'Get distinct course types' })
  getCourseTypes() {
    return this.coursesService.getCourseTypes();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get course by ID' })
  findOne(@Param('id') id: string) {
    return this.coursesService.findOne(id);
  }
}
