import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';

@Injectable()
export class CollegesService {
  constructor(private prisma: PrismaService) {}

  async findAll(filters?: { countryId?: string; search?: string; isActive?: boolean }) {
    const where: any = {};
    if (filters?.countryId) where.countryId = filters.countryId;
    if (filters?.isActive !== undefined) where.isActive = filters.isActive;
    else where.isActive = true;
    if (filters?.search) {
      where.name = { contains: filters.search, mode: 'insensitive' };
    }

    return this.prisma.college.findMany({
      where,
      include: {
        country: { select: { id: true, name: true, code: true } },
        _count: { select: { courses: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async findOne(id: string) {
    const college = await this.prisma.college.findUnique({
      where: { id },
      include: {
        country: true,
        courses: { where: { isActive: true }, orderBy: { name: 'asc' } },
      },
    });
    if (!college) throw new NotFoundException('College not found');
    return college;
  }

  async findAllCountries() {
    return this.prisma.country.findMany({ orderBy: { name: 'asc' } });
  }

  async upsertCollege(data: {
    name: string;
    countryName: string;
    city?: string;
    website?: string;
    description?: string;
  }) {
    // Get or create country
    let country = await this.prisma.country.findUnique({ where: { name: data.countryName } });
    if (!country) {
      country = await this.prisma.country.create({ data: { name: data.countryName } });
    }

    const existing = await this.prisma.college.findUnique({
      where: { name_countryId: { name: data.name, countryId: country.id } },
    });

    if (existing) {
      return this.prisma.college.update({
        where: { id: existing.id },
        data: { city: data.city, website: data.website, isActive: true },
      });
    }

    return this.prisma.college.create({
      data: {
        name: data.name,
        countryId: country.id,
        city: data.city,
        website: data.website,
        description: data.description,
      },
    });
  }
}
