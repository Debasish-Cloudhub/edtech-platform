import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { CollegesService } from './colleges.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

@ApiTags('Colleges')
@Controller('colleges')
export class CollegesController {
  constructor(private collegesService: CollegesService) {}

  // Public endpoints for student portal
  @Get()
  @ApiOperation({ summary: 'List all colleges (public)' })
  @ApiQuery({ name: 'countryId', required: false })
  @ApiQuery({ name: 'search', required: false })
  findAll(@Query('countryId') countryId?: string, @Query('search') search?: string) {
    return this.collegesService.findAll({ countryId, search });
  }

  @Get('countries')
  @ApiOperation({ summary: 'List all countries (public)' })
  findAllCountries() {
    return this.collegesService.findAllCountries();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get college with courses (public)' })
  findOne(@Param('id') id: string) {
    return this.collegesService.findOne(id);
  }
}
