import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../common/prisma/prisma.service';
import { LeadSource, LeadStage } from '@prisma/client';

interface SulekhaLead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  course?: string;
  location?: string;
  createdAt?: string;
}

@Injectable()
export class SulekhaService {
  private readonly logger = new Logger(SulekhaService.name);
  private readonly MAX_RETRIES = 3;

  constructor(
    private prisma: PrismaService,
    private httpService: HttpService,
    private config: ConfigService,
  ) {}

  /**
   * Daily sync at 6 AM
   */
  @Cron('0 6 * * *')
  async scheduledSync() {
    this.logger.log('🔄 Starting scheduled Sulekha sync...');
    await this.syncLeads();
  }

  /**
   * Main sync function - can be triggered manually or via cron
   */
  async syncLeads(): Promise<{
    success: boolean;
    leadsAdded: number;
    leadsSkipped: number;
    errors: string[];
    syncId: string;
  }> {
    const sync = await this.prisma.sulekhaSync.create({
      data: { status: 'RUNNING' },
    });

    let leadsAdded = 0;
    let leadsSkipped = 0;
    const errors: string[] = [];

    try {
      const leads = await this.fetchSulekhaLeads();
      this.logger.log(`Fetched ${leads.length} leads from Sulekha`);

      // Find a default sales agent for auto-assignment
      const defaultAgent = await this.prisma.user.findFirst({
        where: { role: { in: ['SALES_AGENT', 'COUNSELOR'] }, isActive: true },
        orderBy: {
          assignedLeads: { _count: 'asc' }, // assign to agent with fewest leads
        },
      });

      for (const sulekhaLead of leads) {
        try {
          const result = await this.processLead(sulekhaLead, defaultAgent?.id);
          if (result === 'created') leadsAdded++;
          else leadsSkipped++;
        } catch (err) {
          errors.push(`Lead ${sulekhaLead.id}: ${err.message}`);
          leadsSkipped++;
        }
      }

      await this.prisma.sulekhaSync.update({
        where: { id: sync.id },
        data: {
          status: 'SUCCESS',
          completedAt: new Date(),
          leadsAdded,
          leadsSkipped,
          errorMessage: errors.length > 0 ? errors.slice(0, 10).join('; ') : null,
        },
      });

      this.logger.log(`✅ Sulekha sync complete. Added: ${leadsAdded}, Skipped: ${leadsSkipped}`);

      return { success: true, leadsAdded, leadsSkipped, errors, syncId: sync.id };
    } catch (err) {
      await this.prisma.sulekhaSync.update({
        where: { id: sync.id },
        data: { status: 'FAILED', completedAt: new Date(), errorMessage: err.message },
      });
      this.logger.error(`❌ Sulekha sync failed: ${err.message}`);
      throw err;
    }
  }

  private async fetchSulekhaLeads(attempt = 1): Promise<SulekhaLead[]> {
    const apiKey = this.config.get('SULEKHA_API_KEY');
    const apiUrl = this.config.get('SULEKHA_API_URL');

    if (!apiKey || !apiUrl) {
      this.logger.warn('Sulekha API not configured. Using mock data for demo.');
      return this.getMockLeads();
    }

    try {
      const response = await this.httpService.axiosRef.get(apiUrl, {
        headers: { Authorization: `Bearer ${apiKey}` },
        timeout: 15000,
        params: { limit: 200, source: 'education' },
      });
      return response.data?.leads || [];
    } catch (err) {
      if (attempt < this.MAX_RETRIES) {
        this.logger.warn(`Sulekha API attempt ${attempt} failed, retrying...`);
        await new Promise((r) => setTimeout(r, 2000 * attempt));
        return this.fetchSulekhaLeads(attempt + 1);
      }
      throw new Error(`Sulekha API failed after ${this.MAX_RETRIES} retries: ${err.message}`);
    }
  }

  private async processLead(
    sulekhaLead: SulekhaLead,
    defaultAgentId?: string,
  ): Promise<'created' | 'skipped'> {
    // Dedup check by sulekhaId first, then phone, then email
    const existingBySulekhaId = sulekhaLead.id
      ? await this.prisma.lead.findUnique({ where: { sulekhaId: sulekhaLead.id } })
      : null;
    if (existingBySulekhaId) return 'skipped';

    const existingByPhone = await this.prisma.lead.findFirst({
      where: { phone: sulekhaLead.phone, isActive: true },
    });
    if (existingByPhone) return 'skipped';

    if (sulekhaLead.email) {
      const existingByEmail = await this.prisma.lead.findFirst({
        where: { email: sulekhaLead.email, isActive: true },
      });
      if (existingByEmail) return 'skipped';
    }

    // Determine course type from Sulekha data
    const courseInterested = this.detectCourseType(sulekhaLead.course);

    // Find matching country
    let countryId: string | undefined;
    if (sulekhaLead.location) {
      const country = await this.prisma.country.findFirst({
        where: { name: { contains: sulekhaLead.location, mode: 'insensitive' } },
      });
      countryId = country?.id;
    }

    // Create the lead
    const systemUser = await this.prisma.user.findFirst({
      where: { role: 'ADMIN', isActive: true },
    });

    await this.prisma.lead.create({
      data: {
        sulekhaId: sulekhaLead.id,
        name: sulekhaLead.name,
        phone: sulekhaLead.phone,
        email: sulekhaLead.email,
        courseInterested,
        preferredCountry: sulekhaLead.location,
        countryId,
        assignedUserId: defaultAgentId,
        createdByUserId: systemUser!.id,
        stage: LeadStage.INITIATED,
        stageStartDate: new Date(),
        source: LeadSource.SULEKHA,
        notes: `Auto-imported from Sulekha. Course interest: ${sulekhaLead.course || 'Not specified'}`,
      },
    });

    return 'created';
  }

  private detectCourseType(courseStr?: string): string {
    if (!courseStr) return 'BTech';
    const lower = courseStr.toLowerCase();
    if (lower.includes('mba') || lower.includes('management')) return 'MBA';
    if (lower.includes('ms ') || lower.includes('master')) return 'MS';
    if (lower.includes('btech') || lower.includes('b.tech') || lower.includes('engineering')) return 'BTech';
    if (lower.includes('bca') || lower.includes('mca')) return 'MCA';
    return 'BTech';
  }

  async getSyncHistory(limit = 10) {
    return this.prisma.sulekhaSync.findMany({
      orderBy: { startedAt: 'desc' },
      take: limit,
    });
  }

  private getMockLeads(): SulekhaLead[] {
    return [
      { id: 'SLK001', name: 'Aditya Verma', phone: '9811100001', email: 'aditya@example.com', course: 'BTech Computer Science', location: 'India' },
      { id: 'SLK002', name: 'Kavita Nair', phone: '9811100002', email: 'kavita@example.com', course: 'MBA Finance', location: 'USA' },
      { id: 'SLK003', name: 'Rohit Gupta', phone: '9811100003', course: 'B.Tech Mechanical Engineering', location: 'Germany' },
      { id: 'SLK004', name: 'Ananya Sharma', phone: '9811100004', email: 'ananya@example.com', course: 'MBA Marketing', location: 'Canada' },
      { id: 'SLK005', name: 'Kiran Patel', phone: '9811100005', course: 'MS Data Science', location: 'UK' },
    ];
  }
}
