import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { SulekhaController } from './sulekha.controller';
import { SulekhaService } from './sulekha.service';

@Module({
  imports: [HttpModule],
  controllers: [SulekhaController],
  providers: [SulekhaService],
  exports: [SulekhaService],
})
export class SulekhaModule {}
