import { Controller, Post, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { SulekhaService } from './sulekha.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Sulekha')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('sulekha')
export class SulekhaController {
  constructor(private sulekhaService: SulekhaService) {}

  @Post('sync')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Manually trigger Sulekha lead sync' })
  syncNow() {
    return this.sulekhaService.syncLeads();
  }

  @Get('history')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get Sulekha sync history' })
  getHistory() {
    return this.sulekhaService.getSyncHistory();
  }
}
