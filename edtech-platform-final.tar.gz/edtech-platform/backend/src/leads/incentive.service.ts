import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';
import { IncentiveSource } from '@prisma/client';

export interface IncentiveResult {
  amount: number;
  source: IncentiveSource;
  percent?: number;
  fees: number;
}

@Injectable()
export class IncentiveService {
  constructor(private prisma: PrismaService) {}

  /**
   * INCENTIVE CALCULATION LOGIC:
   *
   * Priority order:
   * 1. If course has explicit `incentiveAmount` (from Excel) → use it directly (source: EXCEL)
   * 2. If course has `incentivePercent` (from Excel) → calculate % of fees (source: EXCEL)
   * 3. Else → use system default % from SystemConfig (source: CALCULATED)
   */
  async calculateForCourse(courseId: string): Promise<IncentiveResult | null> {
    const course = await this.prisma.course.findUnique({
      where: { id: courseId },
    });

    if (!course) return null;

    const fees = Number(course.fees);

    // Priority 1: Fixed incentive amount from Excel
    if (course.incentiveAmount) {
      return {
        amount: Number(course.incentiveAmount),
        source: IncentiveSource.EXCEL,
        fees,
      };
    }

    // Priority 2: Percentage from Excel
    if (course.incentivePercent) {
      const percent = Number(course.incentivePercent);
      const amount = parseFloat(((fees * percent) / 100).toFixed(2));
      return {
        amount,
        source: IncentiveSource.EXCEL,
        percent,
        fees,
      };
    }

    // Priority 3: System default percentage
    const defaultConfig = await this.prisma.systemConfig.findUnique({
      where: { key: 'DEFAULT_INCENTIVE_PERCENT' },
    });

    const defaultPercent = parseFloat(defaultConfig?.value || '5');
    const amount = parseFloat(((fees * defaultPercent) / 100).toFixed(2));

    return {
      amount,
      source: IncentiveSource.CALCULATED,
      percent: defaultPercent,
      fees,
    };
  }

  /**
   * Preview incentive for a given college+course (without saving)
   */
  async previewIncentive(courseId: string) {
    const result = await this.calculateForCourse(courseId);
    if (!result) return null;

    const course = await this.prisma.course.findUnique({
      where: { id: courseId },
      include: { college: { select: { name: true } } },
    });

    return {
      collegeName: course?.college.name,
      courseName: course?.name,
      fees: result.fees,
      currency: course?.currency || 'INR',
      incentiveAmount: result.amount,
      incentivePercent: result.percent,
      source: result.source,
      breakdown: `₹${result.amount.toLocaleString()} (${result.percent ? `${result.percent}% of ₹${result.fees.toLocaleString()}` : 'Fixed from Excel'})`,
    };
  }

  /**
   * Bulk recalculate incentives for all open leads
   * Called after admin re-uploads Excel
   */
  async recalculateAllLeads() {
    const leads = await this.prisma.lead.findMany({
      where: {
        courseId: { not: null },
        stage: { notIn: ['WON', 'LOST'] },
        isActive: true,
      },
      select: { id: true, courseId: true },
    });

    let updated = 0;
    for (const lead of leads) {
      if (!lead.courseId) continue;
      const result = await this.calculateForCourse(lead.courseId);
      if (result) {
        await this.prisma.lead.update({
          where: { id: lead.id },
          data: {
            incentiveAmount: result.amount,
            incentiveSource: result.source,
          },
        });
        updated++;
      }
    }
    return { updated };
  }

  /**
   * Get incentive summary for reporting
   */
  async getIncentiveSummary(filters?: { userId?: string; month?: number; year?: number }) {
    const where: any = {
      stage: 'WON',
      isActive: true,
      incentiveAmount: { not: null },
    };

    if (filters?.userId) where.assignedUserId = filters.userId;

    const wonLeads = await this.prisma.lead.findMany({
      where,
      select: {
        id: true,
        name: true,
        incentiveAmount: true,
        incentiveSource: true,
        feesAtClosure: true,
        createdAt: true,
        college: { select: { name: true } },
        course: { select: { name: true } },
        assignedUser: { select: { id: true, name: true } },
      },
    });

    const totalIncentive = wonLeads.reduce((sum, l) => sum + Number(l.incentiveAmount || 0), 0);
    const totalFees = wonLeads.reduce((sum, l) => sum + Number(l.feesAtClosure || 0), 0);

    const byUser = wonLeads.reduce(
      (acc, lead) => {
        const userId = lead.assignedUser?.id || 'unassigned';
        const userName = lead.assignedUser?.name || 'Unassigned';
        if (!acc[userId]) acc[userId] = { name: userName, count: 0, totalIncentive: 0 };
        acc[userId].count++;
        acc[userId].totalIncentive += Number(lead.incentiveAmount || 0);
        return acc;
      },
      {} as Record<string, { name: string; count: number; totalIncentive: number }>,
    );

    return {
      totalWon: wonLeads.length,
      totalIncentive,
      totalFees,
      bySource: {
        EXCEL: wonLeads.filter((l) => l.incentiveSource === 'EXCEL').length,
        CALCULATED: wonLeads.filter((l) => l.incentiveSource === 'CALCULATED').length,
        MANUAL: wonLeads.filter((l) => l.incentiveSource === 'MANUAL').length,
      },
      byUser: Object.values(byUser),
      leads: wonLeads,
    };
  }
}
