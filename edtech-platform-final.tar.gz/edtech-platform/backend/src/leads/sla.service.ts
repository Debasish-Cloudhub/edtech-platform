import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../common/prisma/prisma.service';
import { LeadStage } from '@prisma/client';

@Injectable()
export class SlaService {
  private readonly logger = new Logger(SlaService.name);

  constructor(private prisma: PrismaService) {}

  private async getSlaLimits() {
    const [initiatedConfig, inProgressConfig] = await Promise.all([
      this.prisma.systemConfig.findUnique({ where: { key: 'SLA_INITIATED_DAYS' } }),
      this.prisma.systemConfig.findUnique({ where: { key: 'SLA_IN_PROGRESS_DAYS' } }),
    ]);

    return {
      [LeadStage.INITIATED]: parseInt(initiatedConfig?.value || '7'),
      [LeadStage.IN_PROGRESS]: parseInt(inProgressConfig?.value || '15'),
    };
  }

  /**
   * Runs daily at 8 AM to check SLA breaches
   */
  @Cron('0 8 * * *')
  async checkSlaBreaches() {
    this.logger.log('🕐 Running SLA breach check...');

    const slaLimits = await this.getSlaLimits();
    const now = new Date();

    const activeLeads = await this.prisma.lead.findMany({
      where: {
        stage: { in: [LeadStage.INITIATED, LeadStage.IN_PROGRESS] },
        isActive: true,
      },
      include: {
        assignedUser: { select: { id: true, name: true, email: true } },
      },
    });

    let breachCount = 0;
    let newBreachCount = 0;

    for (const lead of activeLeads) {
      const sladays = slaLimits[lead.stage as LeadStage.INITIATED | LeadStage.IN_PROGRESS];
      if (!sladays) continue;

      const daysSinceStageStart = Math.floor(
        (now.getTime() - new Date(lead.stageStartDate).getTime()) / (1000 * 60 * 60 * 24),
      );

      const isBreach = daysSinceStageStart > sladays;

      if (isBreach) {
        breachCount++;

        if (!lead.slaBreach) {
          // New breach - update and notify
          newBreachCount++;
          await this.prisma.lead.update({
            where: { id: lead.id },
            data: { slaBreach: true, slaBreachDate: now },
          });

          // Log activity
          await this.prisma.leadActivity.create({
            data: {
              leadId: lead.id,
              userId: lead.assignedUserId || lead.createdByUserId,
              type: 'SLA_BREACH',
              content: `SLA breached: Lead in ${lead.stage} for ${daysSinceStageStart} days (limit: ${sladays} days)`,
              metadata: { daysSinceStageStart, slaLimit: sladays },
            },
          });

          // Notify assigned user
          if (lead.assignedUserId) {
            await this.prisma.notification.create({
              data: {
                userId: lead.assignedUserId,
                type: 'SLA_BREACH',
                title: '⚠️ SLA Breach Alert',
                message: `Lead "${lead.name}" (${lead.phone}) has exceeded SLA limit of ${sladays} days in ${lead.stage} stage. Currently at ${daysSinceStageStart} days.`,
                metadata: { leadId: lead.id, stage: lead.stage, daysSinceStageStart },
              },
            });
          }
        }
      } else if (lead.slaBreach && !isBreach) {
        // Lead moved to new stage, reset breach
        await this.prisma.lead.update({
          where: { id: lead.id },
          data: { slaBreach: false, slaBreachDate: null },
        });
      }
    }

    // Send daily summary to all admins
    await this.sendAdminSummary(breachCount, activeLeads.length);

    this.logger.log(
      `✅ SLA check complete. Total breaches: ${breachCount}, New breaches: ${newBreachCount}`,
    );
  }

  private async sendAdminSummary(breachCount: number, totalActive: number) {
    const admins = await this.prisma.user.findMany({
      where: { role: { in: ['ADMIN', 'SUPER_ADMIN'] }, isActive: true },
      select: { id: true },
    });

    // Near breach: leads within 2 days of SLA limit
    const slaLimits = await this.getSlaLimits();
    const now = new Date();

    const allActiveLeads = await this.prisma.lead.findMany({
      where: { stage: { in: ['INITIATED', 'IN_PROGRESS'] }, isActive: true },
      select: { id: true, name: true, stage: true, stageStartDate: true, slaBreach: true },
    });

    const nearBreach = allActiveLeads.filter((lead) => {
      const sladays = slaLimits[lead.stage as LeadStage.INITIATED | LeadStage.IN_PROGRESS];
      if (!sladays) return false;
      const days = Math.floor((now.getTime() - new Date(lead.stageStartDate).getTime()) / (1000 * 60 * 60 * 24));
      return days >= sladays - 2 && !lead.slaBreach;
    });

    for (const admin of admins) {
      await this.prisma.notification.create({
        data: {
          userId: admin.id,
          type: 'DAILY_SLA_SUMMARY',
          title: '📊 Daily SLA Report',
          message: `Active leads: ${totalActive} | SLA Breached: ${breachCount} | Near breach (≤2 days): ${nearBreach.length}`,
          metadata: { breachCount, totalActive, nearBreachCount: nearBreach.length },
        },
      });
    }
  }

  /**
   * Get SLA status for a lead
   */
  async getLeadSlaStatus(leadId: string) {
    const lead = await this.prisma.lead.findUnique({
      where: { id: leadId },
      select: { stage: true, stageStartDate: true, slaBreach: true, slaBreachDate: true },
    });

    if (!lead) return null;

    const slaLimits = await this.getSlaLimits();
    const sladays = slaLimits[lead.stage as LeadStage.INITIATED | LeadStage.IN_PROGRESS];

    if (!sladays) {
      return { stage: lead.stage, slaApplicable: false };
    }

    const now = new Date();
    const daysSinceStageStart = Math.floor(
      (now.getTime() - new Date(lead.stageStartDate).getTime()) / (1000 * 60 * 60 * 24),
    );

    return {
      stage: lead.stage,
      slaApplicable: true,
      slaLimitDays: sladays,
      daysSinceStageStart,
      daysRemaining: sladays - daysSinceStageStart,
      isBreached: lead.slaBreach,
      breachDate: lead.slaBreachDate,
      status:
        lead.slaBreach
          ? 'BREACHED'
          : daysSinceStageStart >= sladays - 2
          ? 'NEAR_BREACH'
          : 'ON_TRACK',
    };
  }

  /**
   * Get all breach reports for admin
   */
  async getBreachReport() {
    const slaLimits = await this.getSlaLimits();
    const now = new Date();

    const leads = await this.prisma.lead.findMany({
      where: { stage: { in: ['INITIATED', 'IN_PROGRESS'] }, isActive: true },
      include: {
        assignedUser: { select: { id: true, name: true, email: true } },
        college: { select: { name: true } },
        course: { select: { name: true } },
      },
      orderBy: { stageStartDate: 'asc' },
    });

    return leads
      .map((lead) => {
        const sladays = slaLimits[lead.stage as LeadStage.INITIATED | LeadStage.IN_PROGRESS];
        const days = Math.floor(
          (now.getTime() - new Date(lead.stageStartDate).getTime()) / (1000 * 60 * 60 * 24),
        );
        return {
          id: lead.id,
          name: lead.name,
          phone: lead.phone,
          stage: lead.stage,
          slaLimitDays: sladays,
          daysSinceStageStart: days,
          daysRemaining: (sladays || 0) - days,
          isBreached: lead.slaBreach,
          assignedUser: lead.assignedUser,
          college: lead.college?.name,
          course: lead.course?.name,
          status: lead.slaBreach ? 'BREACHED' : days >= (sladays || 0) - 2 ? 'NEAR_BREACH' : 'ON_TRACK',
        };
      })
      .sort((a, b) => a.daysRemaining - b.daysRemaining);
  }
}
