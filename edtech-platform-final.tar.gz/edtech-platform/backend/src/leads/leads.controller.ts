import {
  Controller, Get, Post, Put, Patch, Delete, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { LeadsService } from './leads.service';
import { IncentiveService } from './incentive.service';
import { SlaService } from './sla.service';
import {
  CreateLeadDto, UpdateLeadDto, AddNoteDto, AssignLeadDto, IncentivePreviewDto,
} from './dto/create-lead.dto';
import { LeadFilterDto } from './dto/lead-filter.dto';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@ApiTags('Leads')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('leads')
export class LeadsController {
  constructor(
    private leadsService: LeadsService,
    private incentiveService: IncentiveService,
    private slaService: SlaService,
  ) {}

  @Get()
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'List leads (filtered by role)' })
  findAll(@CurrentUser() user: any, @Query() filter: LeadFilterDto) {
    return this.leadsService.findAll(user, filter);
  }

  @Get('stats')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Get lead statistics' })
  getStats(@CurrentUser() user: any) {
    return this.leadsService.getStats(user);
  }

  @Get('sla-report')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get SLA breach report' })
  getSlaReport() {
    return this.slaService.getBreachReport();
  }

  @Get('incentive-summary')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Get incentive payout summary' })
  getIncentiveSummary(@Query('userId') userId?: string) {
    return this.incentiveService.getIncentiveSummary({ userId });
  }

  @Get(':id')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Get lead by ID' })
  findOne(@Param('id') id: string, @CurrentUser() user: any) {
    return this.leadsService.findOne(id, user);
  }

  @Get(':id/sla')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Get SLA status for a lead' })
  getSlaStatus(@Param('id') id: string) {
    return this.slaService.getLeadSlaStatus(id);
  }

  @Get(':id/activities')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Get lead activity log' })
  getActivities(@Param('id') id: string) {
    return this.leadsService.getActivities(id);
  }

  @Post()
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Create a new lead' })
  create(@Body() dto: CreateLeadDto, @CurrentUser() user: any) {
    return this.leadsService.create(dto, user);
  }

  @Post('incentive-preview')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Preview incentive calculation for a course' })
  previewIncentive(@Body() dto: IncentivePreviewDto) {
    return this.incentiveService.previewIncentive(dto.courseId);
  }

  @Put(':id')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Update lead (stage, college, course, etc.)' })
  update(@Param('id') id: string, @Body() dto: UpdateLeadDto, @CurrentUser() user: any) {
    return this.leadsService.update(id, dto, user);
  }

  @Patch(':id/note')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.SALES_AGENT, Role.COUNSELOR)
  @ApiOperation({ summary: 'Add a note to a lead' })
  addNote(@Param('id') id: string, @Body() dto: AddNoteDto, @CurrentUser('sub') userId: string) {
    return this.leadsService.addNote(id, dto.note, userId);
  }

  @Patch(':id/assign')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Reassign lead to a different user (Admin only)' })
  assign(@Param('id') id: string, @Body() dto: AssignLeadDto, @CurrentUser('sub') userId: string) {
    return this.leadsService.assignLead(id, dto.assignedUserId, userId);
  }

  @Delete(':id')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Soft-delete a lead' })
  delete(@Param('id') id: string) {
    return this.leadsService.deleteLead(id);
  }

  @Post('recalculate-incentives')
  @Roles(Role.ADMIN, Role.SUPER_ADMIN)
  @ApiOperation({ summary: 'Recalculate incentives for all active leads after Excel re-upload' })
  recalculateIncentives() {
    return this.incentiveService.recalculateAllLeads();
  }
}
