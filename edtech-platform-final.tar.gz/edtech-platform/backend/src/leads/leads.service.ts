import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';
import { IncentiveService } from './incentive.service';
import { Role, LeadStage, Prisma } from '@prisma/client';
import { CreateLeadDto } from './dto/create-lead.dto';
import { UpdateLeadDto } from './dto/update-lead.dto';
import { LeadFilterDto } from './dto/lead-filter.dto';

@Injectable()
export class LeadsService {
  constructor(
    private prisma: PrismaService,
    private incentiveService: IncentiveService,
  ) {}

  private get leadSelect() {
    return {
      id: true,
      name: true,
      phone: true,
      email: true,
      courseInterested: true,
      preferredCountry: true,
      stage: true,
      stageStartDate: true,
      source: true,
      slaBreach: true,
      slaBreachDate: true,
      notes: true,
      feesAtClosure: true,
      incentiveAmount: true,
      incentiveSource: true,
      createdAt: true,
      updatedAt: true,
      country: { select: { id: true, name: true, code: true } },
      college: { select: { id: true, name: true, city: true } },
      course: { select: { id: true, name: true, courseType: true, fees: true } },
      assignedUser: { select: { id: true, name: true, email: true } },
      createdBy: { select: { id: true, name: true, email: true } },
    };
  }

  async findAll(user: any, filter: LeadFilterDto) {
    const where: Prisma.LeadWhereInput = { isActive: true };

    // Sales agents only see their own leads
    if (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) {
      where.assignedUserId = user.id;
    }

    if (filter.stage) where.stage = filter.stage;
    if (filter.assignedUserId) where.assignedUserId = filter.assignedUserId;
    if (filter.countryId) where.countryId = filter.countryId;
    if (filter.collegeId) where.collegeId = filter.collegeId;
    if (filter.courseInterested) where.courseInterested = filter.courseInterested;
    if (filter.source) where.source = filter.source;
    if (filter.slaBreach !== undefined) where.slaBreach = filter.slaBreach;
    if (filter.search) {
      where.OR = [
        { name: { contains: filter.search, mode: 'insensitive' } },
        { phone: { contains: filter.search } },
        { email: { contains: filter.search, mode: 'insensitive' } },
      ];
    }

    const page = filter.page || 1;
    const limit = filter.limit || 20;
    const skip = (page - 1) * limit;

    const [leads, total] = await Promise.all([
      this.prisma.lead.findMany({
        where,
        select: this.leadSelect,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.lead.count({ where }),
    ]);

    return {
      data: leads,
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOne(id: string, user: any) {
    const lead = await this.prisma.lead.findUnique({
      where: { id },
      select: {
        ...this.leadSelect,
        activities: {
          include: { user: { select: { id: true, name: true } } },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    });

    if (!lead) throw new NotFoundException('Lead not found');

    // Sales agents can only access their assigned leads
    if (
      (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) &&
      (lead as any).assignedUser?.id !== user.id
    ) {
      throw new ForbiddenException('Access denied');
    }

    return lead;
  }

  async create(dto: CreateLeadDto, user: any) {
    // Check for duplicate phone
    const existing = await this.prisma.lead.findFirst({
      where: { phone: dto.phone, isActive: true },
    });
    if (existing) {
      throw new BadRequestException(`Lead with phone ${dto.phone} already exists`);
    }

    // Auto assign to creator if sales agent
    const assignedUserId = dto.assignedUserId || user.id;

    const lead = await this.prisma.lead.create({
      data: {
        name: dto.name,
        phone: dto.phone,
        email: dto.email,
        courseInterested: dto.courseInterested,
        preferredCountry: dto.preferredCountry,
        countryId: dto.countryId,
        collegeId: dto.collegeId,
        courseId: dto.courseId,
        assignedUserId,
        createdByUserId: user.id,
        stage: LeadStage.INITIATED,
        stageStartDate: new Date(),
        source: dto.source || 'MANUAL',
        notes: dto.notes,
      },
      select: this.leadSelect,
    });

    // Log activity
    await this.logActivity(lead.id, user.id, 'CREATED', `Lead created and assigned to sales agent`);

    // Calculate incentive if college+course selected
    if (dto.collegeId && dto.courseId) {
      await this.recalculateIncentive(lead.id, dto.courseId, user.id);
    }

    return lead;
  }

  async update(id: string, dto: UpdateLeadDto, user: any) {
    const lead = await this.prisma.lead.findUnique({ where: { id } });
    if (!lead) throw new NotFoundException('Lead not found');

    if (
      (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) &&
      lead.assignedUserId !== user.id
    ) {
      throw new ForbiddenException('Access denied');
    }

    const prevStage = lead.stage;
    const isStageChanging = dto.stage && dto.stage !== prevStage;

    // Validate WON stage requires college + course
    if (dto.stage === LeadStage.WON) {
      const collegeId = dto.collegeId || lead.collegeId;
      const courseId = dto.courseId || lead.courseId;
      if (!collegeId || !courseId) {
        throw new BadRequestException('College and Course must be selected before marking lead as WON');
      }
    }

    const updateData: any = {
      ...dto,
      updatedAt: new Date(),
    };

    if (isStageChanging) {
      updateData.stageStartDate = new Date();
      updateData.slaBreach = false; // Reset on stage change
    }

    const updated = await this.prisma.lead.update({
      where: { id },
      data: updateData,
      select: this.leadSelect,
    });

    // Log stage change
    if (isStageChanging) {
      await this.logActivity(
        id,
        user.id,
        'STAGE_CHANGE',
        `Stage changed from ${prevStage} to ${dto.stage}`,
        { from: prevStage, to: dto.stage },
      );
    }

    // Recalculate incentive if college/course changed
    const courseId = dto.courseId || lead.courseId;
    if ((dto.collegeId || dto.courseId) && courseId) {
      await this.recalculateIncentive(id, courseId, user.id);
    }

    // Finalize incentive on WON
    if (dto.stage === LeadStage.WON) {
      await this.finalizeIncentive(id, user.id);
    }

    return updated;
  }

  async addNote(id: string, note: string, userId: string) {
    const lead = await this.prisma.lead.findUnique({ where: { id } });
    if (!lead) throw new NotFoundException('Lead not found');

    // Update notes field
    await this.prisma.lead.update({
      where: { id },
      data: { notes: note },
    });

    // Log activity
    return this.logActivity(id, userId, 'NOTE', note);
  }

  async assignLead(id: string, assignedUserId: string, adminUserId: string) {
    const lead = await this.prisma.lead.findUnique({ where: { id } });
    if (!lead) throw new NotFoundException('Lead not found');

    const updated = await this.prisma.lead.update({
      where: { id },
      data: { assignedUserId },
      select: this.leadSelect,
    });

    await this.logActivity(id, adminUserId, 'ASSIGNED', `Lead reassigned`, { assignedUserId });
    return updated;
  }

  async getActivities(leadId: string) {
    return this.prisma.leadActivity.findMany({
      where: { leadId },
      include: { user: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getStats(user: any) {
    const where: any = { isActive: true };
    if (user.role === Role.SALES_AGENT || user.role === Role.COUNSELOR) {
      where.assignedUserId = user.id;
    }

    const [total, byStage, bySource, wonLeads] = await Promise.all([
      this.prisma.lead.count({ where }),
      this.prisma.lead.groupBy({ by: ['stage'], where, _count: true }),
      this.prisma.lead.groupBy({ by: ['source'], where, _count: true }),
      this.prisma.lead.findMany({
        where: { ...where, stage: LeadStage.WON },
        select: { incentiveAmount: true, feesAtClosure: true },
      }),
    ]);

    const totalIncentive = wonLeads.reduce(
      (sum, l) => sum + Number(l.incentiveAmount || 0),
      0,
    );
    const totalRevenue = wonLeads.reduce(
      (sum, l) => sum + Number(l.feesAtClosure || 0),
      0,
    );

    return {
      total,
      byStage: byStage.reduce((acc, s) => ({ ...acc, [s.stage]: s._count }), {}),
      bySource: bySource.reduce((acc, s) => ({ ...acc, [s.source]: s._count }), {}),
      wonCount: wonLeads.length,
      totalIncentive,
      totalRevenue,
    };
  }

  private async recalculateIncentive(leadId: string, courseId: string, userId: string) {
    const result = await this.incentiveService.calculateForCourse(courseId);
    if (!result) return;

    await this.prisma.lead.update({
      where: { id: leadId },
      data: {
        incentiveAmount: result.amount,
        incentiveSource: result.source,
      },
    });

    await this.logActivity(
      leadId,
      userId,
      'INCENTIVE_CALCULATED',
      `Incentive auto-calculated: ₹${result.amount} (${result.source})`,
      { amount: result.amount, source: result.source },
    );
  }

  private async finalizeIncentive(leadId: string, userId: string) {
    const lead = await this.prisma.lead.findUnique({
      where: { id: leadId },
      include: { course: true },
    });

    if (!lead?.course) return;

    const result = await this.incentiveService.calculateForCourse(lead.course.id);
    if (!result) return;

    await this.prisma.lead.update({
      where: { id: leadId },
      data: {
        feesAtClosure: lead.course.fees,
        incentiveAmount: result.amount,
        incentiveSource: result.source,
      },
    });

    await this.logActivity(
      leadId,
      userId,
      'INCENTIVE_FINALIZED',
      `Incentive finalized at ₹${result.amount} upon WON status`,
    );
  }

  async logActivity(
    leadId: string,
    userId: string,
    type: string,
    content: string,
    metadata?: any,
  ) {
    return this.prisma.leadActivity.create({
      data: { leadId, userId, type, content, metadata },
    });
  }

  async deleteLead(id: string) {
    return this.prisma.lead.update({
      where: { id },
      data: { isActive: false },
    });
  }
}
