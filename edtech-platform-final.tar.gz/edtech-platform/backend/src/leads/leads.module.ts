import { Module } from '@nestjs/common';
import { LeadsController } from './leads.controller';
import { LeadsService } from './leads.service';
import { IncentiveService } from './incentive.service';
import { SlaService } from './sla.service';

@Module({
  controllers: [LeadsController],
  providers: [LeadsService, IncentiveService, SlaService],
  exports: [LeadsService, SlaService],
})
export class LeadsModule {}
