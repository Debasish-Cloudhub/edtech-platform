import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create users
  const hashedPassword = await bcrypt.hash('Test@1234', 10);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@test.com' },
    update: {},
    create: {
      name: 'Admin User',
      email: 'admin@test.com',
      phone: '9000000001',
      passwordHash: hashedPassword,
      role: Role.ADMIN,
    },
  });

  const sales = await prisma.user.upsert({
    where: { email: 'sales@test.com' },
    update: {},
    create: {
      name: 'Sales Agent',
      email: 'sales@test.com',
      phone: '9000000002',
      passwordHash: hashedPassword,
      role: Role.SALES_AGENT,
    },
  });

  const student = await prisma.user.upsert({
    where: { email: 'student@test.com' },
    update: {},
    create: {
      name: 'Test Student',
      email: 'student@test.com',
      phone: '9000000003',
      passwordHash: hashedPassword,
      role: Role.STUDENT,
    },
  });

  const finance = await prisma.user.upsert({
    where: { email: 'finance@test.com' },
    update: {},
    create: {
      name: 'Finance Manager',
      email: 'finance@test.com',
      phone: '9000000004',
      passwordHash: hashedPassword,
      role: Role.FINANCE_MANAGER,
    },
  });

  console.log('✅ Users created:', { admin: admin.email, sales: sales.email, student: student.email });

  // Create countries
  const india = await prisma.country.upsert({
    where: { name: 'India' },
    update: {},
    create: { name: 'India', code: 'IN' },
  });

  const usa = await prisma.country.upsert({
    where: { name: 'USA' },
    update: {},
    create: { name: 'USA', code: 'US' },
  });

  const uk = await prisma.country.upsert({
    where: { name: 'UK' },
    update: {},
    create: { name: 'UK', code: 'GB' },
  });

  const canada = await prisma.country.upsert({
    where: { name: 'Canada' },
    update: {},
    create: { name: 'Canada', code: 'CA' },
  });

  const germany = await prisma.country.upsert({
    where: { name: 'Germany' },
    update: {},
    create: { name: 'Germany', code: 'DE' },
  });

  console.log('✅ Countries created');

  // Create colleges
  const collegesData = [
    { name: 'IIT Delhi', countryId: india.id, city: 'New Delhi' },
    { name: 'IIT Bombay', countryId: india.id, city: 'Mumbai' },
    { name: 'IIM Ahmedabad', countryId: india.id, city: 'Ahmedabad' },
    { name: 'IIM Bangalore', countryId: india.id, city: 'Bangalore' },
    { name: 'MIT', countryId: usa.id, city: 'Cambridge, MA' },
    { name: 'Stanford University', countryId: usa.id, city: 'Stanford, CA' },
    { name: 'Harvard Business School', countryId: usa.id, city: 'Boston, MA' },
    { name: 'University of Toronto', countryId: canada.id, city: 'Toronto' },
    { name: 'University of Oxford', countryId: uk.id, city: 'Oxford' },
    { name: 'TU Munich', countryId: germany.id, city: 'Munich' },
  ];

  const colleges: any = {};
  for (const col of collegesData) {
    const c = await prisma.college.upsert({
      where: { name_countryId: { name: col.name, countryId: col.countryId } },
      update: {},
      create: col,
    });
    colleges[col.name] = c;
  }

  console.log('✅ Colleges created');

  // Create courses
  const coursesData = [
    // IIT Delhi
    { name: 'B.Tech Computer Science', collegeId: colleges['IIT Delhi'].id, courseType: 'BTech', duration: '4 years', fees: 800000, incentivePercent: 5 },
    { name: 'B.Tech Mechanical Engineering', collegeId: colleges['IIT Delhi'].id, courseType: 'BTech', duration: '4 years', fees: 750000, incentivePercent: 5 },
    // IIT Bombay
    { name: 'B.Tech Electrical Engineering', collegeId: colleges['IIT Bombay'].id, courseType: 'BTech', duration: '4 years', fees: 820000, incentivePercent: 5 },
    { name: 'B.Tech Data Science', collegeId: colleges['IIT Bombay'].id, courseType: 'BTech', duration: '4 years', fees: 850000, incentivePercent: 5.5 },
    // IIM Ahmedabad
    { name: 'MBA General Management', collegeId: colleges['IIM Ahmedabad'].id, courseType: 'MBA', duration: '2 years', fees: 2500000, incentivePercent: 4 },
    { name: 'MBA Finance', collegeId: colleges['IIM Ahmedabad'].id, courseType: 'MBA', duration: '2 years', fees: 2600000, incentivePercent: 4 },
    // IIM Bangalore
    { name: 'MBA Marketing', collegeId: colleges['IIM Bangalore'].id, courseType: 'MBA', duration: '2 years', fees: 2400000, incentivePercent: 4 },
    // MIT
    { name: 'MS Computer Science', collegeId: colleges['MIT'].id, courseType: 'BTech', duration: '2 years', fees: 4500000, incentivePercent: 6, currency: 'INR' },
    { name: 'MBA Sloan', collegeId: colleges['Harvard Business School'].id, courseType: 'MBA', duration: '2 years', fees: 6000000, incentivePercent: 6, currency: 'INR' },
    // Stanford
    { name: 'MS Artificial Intelligence', collegeId: colleges['Stanford University'].id, courseType: 'BTech', duration: '2 years', fees: 5000000, incentivePercent: 6.5 },
    { name: 'MBA', collegeId: colleges['Stanford University'].id, courseType: 'MBA', duration: '2 years', fees: 5500000, incentivePercent: 6 },
    // Canada
    { name: 'M.Eng Computer Engineering', collegeId: colleges['University of Toronto'].id, courseType: 'BTech', duration: '1.5 years', fees: 2200000, incentivePercent: 5 },
    // UK
    { name: 'MBA Oxford Said', collegeId: colleges['University of Oxford'].id, courseType: 'MBA', duration: '1 year', fees: 4800000, incentivePercent: 5.5 },
    // Germany
    { name: 'M.Sc Mechanical Engineering', collegeId: colleges['TU Munich'].id, courseType: 'BTech', duration: '2 years', fees: 800000, incentivePercent: 4 },
  ];

  for (const course of coursesData) {
    await prisma.course.create({
      data: {
        name: course.name,
        collegeId: course.collegeId,
        courseType: course.courseType,
        duration: course.duration,
        fees: course.fees,
        currency: course.currency || 'INR',
        incentivePercent: course.incentivePercent,
      },
    }).catch(() => {}); // Skip if exists
  }

  console.log('✅ Courses created');

  // Create sample leads
  const salesUser = await prisma.user.findUnique({ where: { email: 'sales@test.com' } });
  const iitCourse = await prisma.course.findFirst({ where: { name: 'B.Tech Computer Science' } });
  const iitCollege = await prisma.college.findFirst({ where: { name: 'IIT Delhi' } });

  const leadsData = [
    {
      name: 'Rahul Sharma',
      phone: '9876543210',
      email: 'rahul@example.com',
      courseInterested: 'BTech',
      preferredCountry: 'India',
      countryId: india.id,
      collegeId: iitCollege?.id,
      courseId: iitCourse?.id,
      assignedUserId: salesUser?.id,
      createdByUserId: salesUser!.id,
      stage: 'INITIATED' as any,
      source: 'MANUAL' as any,
      notes: 'Interested in CS programs',
    },
    {
      name: 'Priya Patel',
      phone: '9876543211',
      email: 'priya@example.com',
      courseInterested: 'MBA',
      preferredCountry: 'USA',
      countryId: usa.id,
      assignedUserId: salesUser?.id,
      createdByUserId: salesUser!.id,
      stage: 'IN_PROGRESS' as any,
      source: 'SULEKHA' as any,
      stageStartDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      notes: 'Looking for MBA abroad',
    },
    {
      name: 'Arjun Kumar',
      phone: '9876543212',
      email: 'arjun@example.com',
      courseInterested: 'BTech',
      preferredCountry: 'Germany',
      countryId: germany.id,
      assignedUserId: salesUser?.id,
      createdByUserId: admin.id,
      stage: 'WON' as any,
      source: 'WEBSITE' as any,
      feesAtClosure: 800000,
      incentiveAmount: 32000,
      incentiveSource: 'CALCULATED' as any,
      notes: 'Admitted to TU Munich',
    },
    {
      name: 'Sneha Reddy',
      phone: '9876543213',
      email: 'sneha@example.com',
      courseInterested: 'MBA',
      preferredCountry: 'India',
      countryId: india.id,
      assignedUserId: salesUser?.id,
      createdByUserId: salesUser!.id,
      stage: 'LOST' as any,
      source: 'MANUAL' as any,
      notes: 'Chose a different consultant',
    },
    {
      name: 'Vikram Singh',
      phone: '9876543214',
      email: 'vikram@example.com',
      courseInterested: 'BTech',
      preferredCountry: 'Canada',
      countryId: canada.id,
      assignedUserId: salesUser?.id,
      createdByUserId: salesUser!.id,
      stage: 'INITIATED' as any,
      source: 'SULEKHA' as any,
      stageStartDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago - SLA breach
      notes: 'Interested in Canada engineering programs',
    },
  ];

  for (const lead of leadsData) {
    await prisma.lead.create({ data: lead }).catch(() => {});
  }

  console.log('✅ Leads created');

  // System config defaults
  await prisma.systemConfig.upsert({
    where: { key: 'DEFAULT_INCENTIVE_PERCENT' },
    update: {},
    create: { key: 'DEFAULT_INCENTIVE_PERCENT', value: '5' },
  });

  await prisma.systemConfig.upsert({
    where: { key: 'SLA_INITIATED_DAYS' },
    update: {},
    create: { key: 'SLA_INITIATED_DAYS', value: '7' },
  });

  await prisma.systemConfig.upsert({
    where: { key: 'SLA_IN_PROGRESS_DAYS' },
    update: {},
    create: { key: 'SLA_IN_PROGRESS_DAYS', value: '15' },
  });

  console.log('✅ System config seeded');
  console.log('\n🎉 Seeding complete!');
  console.log('\n📋 Test Credentials:');
  console.log('  admin@test.com / Test@1234 (Admin)');
  console.log('  sales@test.com / Test@1234 (Sales Agent)');
  console.log('  student@test.com / Test@1234 (Student)');
  console.log('  finance@test.com / Test@1234 (Finance Manager)');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
